/* ====================================================================================================

  Powder Of Life
  Config script

  ---

  This script is the main file that has global level elements and loads other scripts.

  ---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the
  GNU General Public License as published by the Free Software Foundation, either version 3 of the
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

  ==================================================================================================== */

// Global Constants
// 10-bit input
#define ANALOG_INPUT_MIN 0
#define ANALOG_INPUT_MAX 1023
// 8-bit output
#define ANALOG_OUTPUT_MIN 0
#define ANALOG_OUTPUT_MAX 255
// 1-bit input
#define DIGITAL_INPUT_MIN 0
#define DIGITAL_INPUT_MAX 1
// POL normalize range
#define POL_NORMALIZE_MIN 0.0
#define POL_NORMALIZE_MAX 1.0

// Serial
#define SERIAL_BAUD_RATE_DEBUG 9600
#define SERIAL_BAUD_RATE_MIDI 31250
#define SERIAL_BAUD_RATE_DEFAULT 19200

// Parsing symbols
#define SERIAL_MESSAGE_OPEN '<'
#define SERIAL_MESSAGE_CLOSE '>'
#define SERIAL_MESSAGE_LINEBREAK true
#define SERIAL_PAIR_SPLIT ':'
#define SERIAL_VALUE_SPLIT '|'
#define SERIAL_FLOAT_DECIMALS 4

// Neuron defaults
#define NEURON_FRAME_TIME 0.02
#define NEURON_NORMAL_DECAY 0.1
#define NEURON_NORMAL_BAND 0.1
#define NEURON_NORMAL_FRAME_SKIP 20

// POL engine (this clas)
#define POL_ENGINE_NUM_OF_NEURONS 20


// Includes

// Utilities
#include "Arduino.h"

#include "Toolkit.h"

#include "Timer.h"

#include "RailcarLerp.h"

#include "Curvinator.h"

#include "ScaleMapper.h"

//#include "Mixer.h"


// Base types
#include "Neuron.h"
#include "Engine.h"

// Sensors
#include "AnalogSensor.h"
//#include "DigitalInputSensor.h"
//#include "AccelerometerSensor.h"
//#include "AudioSensor.h"
#include "ButtonSensor.h"
#include "DistanceSensor.h"
#include "MPUSensor.h"
#include "SerialSensor.h"
#include "EncoderSensor.h"

// Drivers
#include "AnalogDriver.h"
#include "MotorDriver.h"
#include "MidiDriver.h"
#include "ServoDriver.h"
#include "StepperDriver.h"
#include "SerialDriver.h"
#include "ToneDriver.h"

// Generators
#include "RandomGenerator.h"
//#include "ContinuousGenerator.h"
#include "BeatGenerator.h"

// Nodes
#include "LerpNode.h"
//#include "EncodedMotorNode.h"
//#include "MixNode.h"
#include "SustainNode.h"
#include "CloneNode.h"

// EOF
