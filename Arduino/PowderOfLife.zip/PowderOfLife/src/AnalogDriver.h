/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Analog Driver

  ===========================

  This is a basic driver that simply uses the standard Arduino analog output (PWM, bit-depth dependent on board).

  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2024
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

  ==================================================================================================== */


class AnalogDriver : public Driver {
  private:
    int outputPin;
  protected:
    void wake();
  public:
    AnalogDriver();
    void work();
    void setPin(int newPin);
    //void setInternalValue(float newValue);
};


// constructor
AnalogDriver::AnalogDriver() {
  setNormal(normalMode::custom);
  setNormalClip(normalClip::clip);
}

void AnalogDriver::wake() {
}


void AnalogDriver::work() {
  updateInput();
  // Map to output range
  float output = Toolkit::mapf( getValue(), 0, 1, ANALOG_OUTPUT_MIN, ANALOG_OUTPUT_MAX);
  // Constrain to avoid overflow of output bit-depth
  output = Toolkit::constrainf(output, ANALOG_OUTPUT_MIN, ANALOG_OUTPUT_MAX );
  // Output
  analogWrite( outputPin, output );
}

void AnalogDriver::setPin(int newPin) {
  outputPin = newPin;
  pinMode(outputPin, OUTPUT);
}


// EOF
