/* ====================================================================================================

  Powder Of Life
  Analog Driver
  
---

  This is a basic driver that simply uses the standard Arduino analog output (PWM, bit-depth dependent on board).
 
---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the 
  GNU General Public License as published by the Free Software Foundation, either version 3 of the 
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

==================================================================================================== */


class AnalogDriver : public Driver {
  private:
    int outputPin;
  protected:
    void wake();
  public:
    AnalogDriver();
    void work();
    void setPin(int newPin);
};


// constructor
AnalogDriver::AnalogDriver() {
  setNormal(normalMode::none);
}

void AnalogDriver::wake(){
}


void AnalogDriver::work() {
  //int output = mapf( getInput().getValue(), 0, 1, ANALOG_OUTPUT_MIN, ANALOG_OUTPUT_MAX);
  setValue(getInput().getValue());
  analogWrite( outputPin, Toolkit::mapf( getValue(), 0, 1, ANALOG_OUTPUT_MIN, ANALOG_OUTPUT_MAX) );
}

void AnalogDriver::setPin(int newPin) {
  outputPin = newPin;
  pinMode(outputPin, OUTPUT);
}
