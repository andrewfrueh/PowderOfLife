/* ====================================================================================================

  Powder Of Life
  Servo Driver
    extends Driver

---
  
  Controls a basic servo motor with standard Arduino PWM output.
   
---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the 
  GNU General Public License as published by the Free Software Foundation, either version 3 of the 
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

==================================================================================================== */


// TODO
// straight mapping to 180 degrees
// more?

// has dependency on Servo library
#include <Servo.h>



class ServoDriver : public Neuron {
  private:
    int outputPin;
    Servo servoObject;
    const int servoRangeMin = 15; // needed to adjust up for servos hitting their end and buzzing
    const int servoRangeMax = 180;
  public:
    ServoDriver();
    //
    void work();
    void setPin(int newPin);
};


// constructor
ServoDriver::ServoDriver() {
  //SetLerpProperties(SERVODRIVER_LERP_SPEED, SERVODRIVER_LERP_ACCEL);
  setNormalize(normalizeScale::custom, normalizeClip::clip, 0.0, 1.0);
}

void ServoDriver::setPin(int newPin){
  outputPin = newPin;
  servoObject.attach(outputPin);
}

void ServoDriver::work() {
  setValue(getInputNeuron().getValue());
  int pos = Toolkit::mapf( getValue(), 0, 1, servoRangeMin, servoRangeMax);
  servoObject.write(pos);
}
