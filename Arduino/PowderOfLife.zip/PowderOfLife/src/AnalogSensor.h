/* ====================================================================================================

  Powder Of Life
  Analog Sensor

  ---

  This is a basic sensor that simply gives you the standard Arduino analog input (bit-depth dependent on board).

  ---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the
  GNU General Public License as published by the Free Software Foundation, either version 3 of the
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

  ==================================================================================================== */

/*
  TODO
    - create an int for the center offset point (not necessarily 512)
    - FIX see below
*/

class AnalogSensor : public Sensor {
  private:
    float rawInput;
    int analogInputPin;
  protected:
    // Overidden
    void wake();
    void workFast();
  public:
    AnalogSensor();
    //
    void work();
    void setPin(int newPin);
};


// constructor
AnalogSensor::AnalogSensor() {
  setNormal(normalMode::custom, normalClip::invert, 0, 1023);
}

void AnalogSensor::wake(){
}

void AnalogSensor::workFast() {
  //
  //rawInput = ANALOG_INPUT_MAX - analogRead(analogInputPin);
  rawInput = analogRead(analogInputPin);
}


void AnalogSensor::work() {
  //
  //lerp.setTarget(rawInput);
  //lerp.update();
  //
  //setValue(lerp.getValue());
  setValue(rawInput);
  /*
  Serial.print(rawInput);
  Serial.print(",");
  Serial.print(getValue());
  Serial.print(",");
  Serial.print(GetNormalizingMin());
  Serial.print(",");
  Serial.print(GetNormalizingMax());
  Serial.print(",0,1023");
  Serial.println();
  */
}

void AnalogSensor::setPin(int newPin) {
  analogInputPin = newPin;
  //pinMode(analogInputPin, INPUT);
}


/*
  // TODO
  // BROKEN!!!
  // Could have the center be chosen as the average between the min / max -- that way it auto-centers
  void AnalogSensor::SetCenterOffset(bool newState, float newPoint=-1) {
  useCenterOffset = newState;
  //centerOffsetPoint = newPoint==-1 ? (ANALOG_INPUT_MAX / 2) : newPoint;
  }
*/
