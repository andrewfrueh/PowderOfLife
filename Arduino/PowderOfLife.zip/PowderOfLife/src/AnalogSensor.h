/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Analog Sensor
  
  ===========================

  This is a basic sensor that simply gives you the standard Arduino analog input (bit-depth dependent on board).
   
  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2022
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

==================================================================================================== */





/*
  TODO
    - create an int for the center offset point (not necessarily 512)
    - FIX see below
*/

class AnalogSensor : public Sensor {
  private:
    float rawInput;
    int analogInputPin;
    int centerPoint;
  protected:
    // Overidden
    void wake();
    void workFast();
  public:
    AnalogSensor();
    //
    void work();
    void setPin(int newPin);
    void setCenter(int newCenter);
    void setCenter(float newCenter);
};

//  

// constructor
AnalogSensor::AnalogSensor() {
  setCenter(0);
  //setNormal(normalMode::custom, normalClip::clip, 0, 1023 ); 
}

void AnalogSensor::wake(){
}

void AnalogSensor::workFast() {
  //
  //rawInput = ANALOG_INPUT_MAX - analogRead(analogInputPin);
  rawInput = analogRead(analogInputPin);
}


void AnalogSensor::work() {
  //
  //lerp.setTarget(rawInput);
  //lerp.update();
  //
  //setValue(lerp.getValue());
  setValue(rawInput);
  /*
  Serial.print(rawInput);
  Serial.print(",");
  Serial.print(getValue());
  Serial.print(",");
  Serial.print(GetNormalizingMin());
  Serial.print(",");
  Serial.print(GetNormalizingMax());
  Serial.print(",0,1023");
  Serial.println();
  */
}

void AnalogSensor::setPin(int newPin) {
  analogInputPin = newPin;
  //pinMode(analogInputPin, INPUT);
}

void AnalogSensor::setCenter(int newCenter){
  centerPoint = newCenter;
  setNormal(normalMode::custom, normalClip::clip, centerPoint, 1023, 0, 0, true); // abs
}


void AnalogSensor::setCenter(float newCenter){
  setCenter((int)(newCenter*1023)); // cast to int
}


/*
  // TODO
  // BROKEN!!!
  // Could have the center be chosen as the average between the min / max -- that way it auto-centers
  void AnalogSensor::SetCenterOffset(bool newState, float newPoint=-1) {
  useCenterOffset = newState;
  //centerOffsetPoint = newPoint==-1 ? (ANALOG_INPUT_MAX / 2) : newPoint;
  }
*/
