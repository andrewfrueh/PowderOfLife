/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Analog Sensor

  ===========================

  This is a basic sensor that simply gives you the standard Arduino analog input (bit-depth dependent on board).

  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2024
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

  ==================================================================================================== */


// TODO 
// - add curvination





class AnalogSensor : public Sensor {
  private:
    float rawInput;
    int analogInputPin;
    int centerPoint;
  protected:
    // Overidden
    void wake();
    void workFast();
  public:
    AnalogSensor();
    //
    void work();
    void setPin(int newPin);
    void setCenter(int newCenter);
    void setCenter(float newCenter);
    // void setCurve(Curvinator::mode newMode, float newExpo);
};

//

// constructor
AnalogSensor::AnalogSensor() {
  setCenter(0);
  setNormal(normalMode::custom, normalClip::clip, 0, 1023 );
  setPinType(Sensor::pinType::analog);
  // setCurve(Curvinator::mode::none, 1.0);
}

void AnalogSensor::wake() {
}

void AnalogSensor::workFast() {
  rawInput = analogRead(analogInputPin);
}


void AnalogSensor::work() {
  setInternalValue(rawInput);
}

void AnalogSensor::setPin(int newPin) {
  analogInputPin = newPin;
  //pinMode(analogInputPin, INPUT);
  setPinInputMode(analogInputPin);
}

void AnalogSensor::setCenter(int newCenter) {
  centerPoint = newCenter;
  setNormal(normalMode::custom, normalClip::clip, centerPoint, 1023, true); // abs
}


void AnalogSensor::setCenter(float newCenter) {
  setCenter((int)(newCenter * 1023)); // cast to int
}


// void AnalogSensor::setCurve(Curvinator::mode newMode, float newExpo){
//   curveType = newMode;
//   curveExpo = newExpo;
// }


/*
  // TODO
  // BROKEN!!!
  // Could have the center be chosen as the average between the min / max -- that way it auto-centers
  void AnalogSensor::SetCenterOffset(bool newState, float newPoint=-1) {
  useCenterOffset = newState;
  //centerOffsetPoint = newPoint==-1 ? (ANALOG_INPUT_MAX / 2) : newPoint;
  }
*/
