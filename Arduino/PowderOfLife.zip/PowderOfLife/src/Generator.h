/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Generator
  
  ===========================

  The Generator class is a second-level super-class for all Generator sub-classes (e.g. RandomGenerator).
  The Generator class is not meant to be instantiated directly. 

  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2024
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

==================================================================================================== */



class Generator : public Node{
  public:
    Generator();
};

// Constructor
Generator::Generator(){
}
