

class Generator : public Node{
  public:
    Generator();
};

// Constructor
Generator::Generator(){
}
