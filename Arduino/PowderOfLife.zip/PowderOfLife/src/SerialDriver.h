/* ====================================================================================================

  Powder Of Life
  Serial Driver
    extends Driver

---
  
  Writes to the serial port. Used to create a channel for connecting to Neurons outside of this Arduino context.
   
---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the 
  GNU General Public License as published by the Free Software Foundation, either version 3 of the 
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

==================================================================================================== */


class SerialDriver : public Neuron {
  private:
    String channelName;
    byte floatDepth;
    //void PrintFloat(double number, uint8_t digits);
  public:
    SerialDriver();
    void work();
    void setName(String newName);
    void setDepth(byte newDepth);
    void writeData(float data);
};


// constructor
SerialDriver::SerialDriver() {
  setFrameTime(0.03);
  setNormal(normalMode::none);
  floatDepth = SERIAL_FLOAT_DECIMALS;
}


void SerialDriver::work(){
  // Only update if different
  if( getInput().getValue() != getValue() ){
    setValue(getInput().getValue());
    writeData(getValue());
  }
  //
}


void SerialDriver::setName(String newName){
  channelName = newName;
}

void SerialDriver::writeData(float data){
  Serial.print(SERIAL_MESSAGE_OPEN);
  Serial.print(channelName);
  Serial.print(SERIAL_PAIR_SPLIT);
  Toolkit::printFloat(data,floatDepth);
  Serial.print(SERIAL_MESSAGE_CLOSE);
  if(SERIAL_MESSAGE_LINEBREAK){
    Serial.println();
  }

  
}


void SerialDriver::setDepth(byte newDepth){
  floatDepth = newDepth;
}

// EOF
