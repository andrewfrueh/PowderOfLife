/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Serial Driver
  
  ===========================

  Writes to the serial port. Used to create a channel for connecting to Neurons outside of this Arduino context.
   
  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2022
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

==================================================================================================== */




class SerialDriver : public Driver {
  private:
    String channelName;
    byte floatDepth;
    //void PrintFloat(double number, uint8_t digits);
  public:
    SerialDriver();
    void work();
    void setName(String newName);
    void setDepth(byte newDepth);
    void writeData(float data);
};


// constructor
SerialDriver::SerialDriver() {
  setFrameTime(0.03);
  setNormal(normalMode::none);
  floatDepth = SERIAL_FLOAT_DECIMALS;
}


void SerialDriver::work(){
  //updateInput();
  // Only update if different
  if( getInput().getValue() != getValue() ){
    setInternalValue(getInput().getValue());
    writeData(getValue());
  }
  //
}


void SerialDriver::setName(String newName){
  channelName = newName;
}

void SerialDriver::writeData(float data){
  Serial.print(SERIAL_MESSAGE_OPEN);
  Serial.print(channelName);
  Serial.print(SERIAL_PAIR_SPLIT);
  Toolkit::printFloat(data,floatDepth);
  Serial.print(SERIAL_MESSAGE_CLOSE);
  if(SERIAL_MESSAGE_LINEBREAK){
    Serial.println();
  }

  
}


void SerialDriver::setDepth(byte newDepth){
  floatDepth = newDepth;
}

// EOF
