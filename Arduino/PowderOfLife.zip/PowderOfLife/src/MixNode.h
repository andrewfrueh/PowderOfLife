/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Mix Node
  
  ===========================

  This node takes input from two neurons and mixes them to create an output.
   
  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2022
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

==================================================================================================== */



class MixNode : public Node {
  private:
    //Neuron* inputNeuronB; // second input neuron
    byte mixMode;
  protected:
    float frameTime = 0.001;
  public:
    MixNode();
    //
    void work();
    void setMode(Mixer::mode newMode);
};


// constructor
MixNode::MixNode() {
  //
  setNormal(Neuron::normalMode::none);
  //
  setMode(Mixer::mode::average);
}

void MixNode::work() {
  // Need to fix input to handle multiple refs. first
  setValue( Mixer::Mix( getInput(0).getValue(), getInput(1).getValue(), mixMode ) );
}



void MixNode::setMode(Mixer::mode newMode) {
  mixMode = newMode;
}

//
