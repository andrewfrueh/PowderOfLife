/* ====================================================================================================

  Powder Of Life
  Mix Node
    extends Node

---

  This node takes input from two neurons and mixes them to create an output.

---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the 
  GNU General Public License as published by the Free Software Foundation, either version 3 of the 
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

==================================================================================================== */

/*
  TODO

	- Use the new Mixer class
*/


//#define MIXNODE_DEFAULT_MODE MixerTypes::average

class MixNode : public Node {
  private:
    //Neuron* inputNeuronB; // second input neuron
    byte mixMode;
  protected:
    float frameTime = 0.001;
  public:
    MixNode();
    //
    void work();
    void setMode(Mixer::modes newMode);
};


// constructor
MixNode::MixNode() {
  //
  setNormal(normalMode::none);
  //
  setMode(Mixer::modes::average);
}

void MixNode::work() {
  // Need to fix input to handle multiple refs. first
  setValue( Mixer::Mix( getInput(0).getValue(), getInput(1).getValue(), mixMode ) );
}



void MixNode::setMode(Mixer::modes newMode) {
  mixMode = newMode;
}

//
