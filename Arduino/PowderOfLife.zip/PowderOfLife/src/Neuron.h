/* ====================================================================================================

  Powder Of Life
  Neuron

  ---

  TODO

  ---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the
  GNU General Public License as published by the Free Software Foundation, either version 3 of the
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

  ==================================================================================================== */


class Neuron {
  private:
    // ===================
    // reference to the input neuron
    Neuron* inputNeuron;
    // ===================
    // the current value
    float rawValue;
    float value;
    bool valueIsValid = true;
    bool state;
    // internal states
    bool enabled = true;
    // frame timer
    Timer frameTimer;
    byte frameSkipDecay; // decay auto normal every x frames
    // ===================
    // automatic / custom normalizing
    float normalRangeMin;
    float normalRangeMax;
    float normalRangeDecay; // alt var 1
    float normalRangeBand; // alt var 2
    // We can use char for storing the enum options as the enums are defined internally
    byte normalizationScale;
    byte normalizationClip;
    bool normalAbsolute;
    // ===================
    // Virtual methods will be overwritten in subclasses (# may need to be "protected" #)
  protected:
    // ===================
    virtual void wake();
    virtual void workFast();
    virtual void work();
    // ===================
    // Events (permission will be shifted to public when overridden)
    // How can these work? The receiving neuron imliments? IDK! Barf. Whatever, just use the kludey ones below
    /*
      virtual void onDown();
      virtual void onUp();
    */
  public:
    // Constructor
    Neuron();
    // ===================
    // Core functionality
    void start();
    void update();
    void setEnabled(bool newEnabled);
    bool getEnabled();
    void setCloning(bool newCloning);
    bool getCloning();
    void setFrameTime(float newTime);
    float getFrameTime();
    float getFrameDelta();
    // ===================
    // Input neuron
    void setInput(Neuron &newNeuron); // C++ use Neuron by reference
    Neuron& getInput(); // C++ use Neuron by reference
    bool hasInput();
    // ===================
    // Value
    void setValue(float newValue);
    float getValue();
    float getRawValue();
    bool getState(); // current binary state
    void setValueIsValid(bool newValid);
    bool getValueIsValid();
    //void setInvert(bool newInvert);
    // ===================
    // these are pseudo-events, but they are easy to use. keep them even if you get actual events working
    bool getDown(); // on down, true only once
    bool getUp(); // on up, true only once
    // ===================
    // enum lists for options
    enum normalMode : byte { none, automatic, custom, slide, steer }; // type of normalization to apply to the input
    enum normalClip : byte { clip, overflow, invert }; // to clip or not to clip the output,
    // Normalize
    void setNormal(
      normalMode newScale = normalMode::automatic,
      normalClip newClip = normalClip::clip,
      float p1 = 0.0,
      float p2 = 0.0,
      float p3 = 0.0,
      float p4 = 0.0,
      bool newAbs = false
    );
    void doNormalDecay();
    // ===================
    // Input range
    void setNormalRange(float newMin, float newMax);
    float getNormalMin();
    float getNormalMax();
    // ===================
    byte stateChange; // 0 is null, 1 is down, 2 is up // ### WHY IS THIS PUBLIC??
};

// Constructor
Neuron::Neuron() {
  setFrameTime(NEURON_FRAME_TIME);
  setNormal(normalMode::automatic, normalClip::clip, NEURON_NORMAL_DECAY, NEURON_NORMAL_FRAME_SKIP, NEURON_NORMAL_BAND);
}

// ==================================================================
// Core functionality

// To be called by the main program
void Neuron::start() {
  // Calls startup on instance
  wake();
}

void Neuron::update() {
  // The main loop
  if ( enabled ) {
    // workFast is outside the frame timer
    workFast();
    // Render a frame?
    if (frameTimer.interval()) {
      // work() is inside the frame timer
      work();
      // Decay auto levels?
      doNormalDecay();
    }
  } else {
    // Neuron is disabled
  }
}

// These virtual methods are to be overridden by subclasses

// To be overridden
void Neuron::wake() {
}

// To be overridden
void Neuron::workFast() {
}

// To be overridden
void Neuron::work() {
}


/*
  // one day...
  // To be overridden
  void Neuron::onDown() {
  }

  // To be overridden
  void Neuron::onUp() {
  }
*/

void Neuron::setEnabled(bool newEnabled) {
  enabled = newEnabled;
}

bool Neuron::getEnabled() {
  return enabled;
}


void Neuron::setFrameTime(float newTime) {
  frameTimer.setRate(newTime);
}

// Arduino can't work the float math for micros
float Neuron::getFrameTime() {
  return frameTimer.getRate();
}

float Neuron::getFrameDelta() {
  return frameTimer.getDelta();
}


// ==================================================================
// Input neuron

// C++ use Neuron by reference
void Neuron::setInput(Neuron &newNeuron) {
  inputNeuron = &newNeuron;
}

// C++ use Neuron by reference
Neuron& Neuron::getInput() {
  return *inputNeuron;
}


bool Neuron::hasInput() {
  return (inputNeuron != NULL) ? true : false;
}


// ==================================================================
// Value


void Neuron::setValue(float newValue) {
  rawValue = newValue;

  // Scale: none, automatic, custom
  switch (normalizationScale) { // for C++ use case: static_cast<normalMode>(normalizationScale)
    case normalMode::automatic:
    case normalMode::slide:
      // Learning / memory

      if (newValue < normalRangeMin) { // check min
        normalRangeMin = newValue;
        if (normalizationScale == normalMode::slide) {
          normalRangeMax = normalRangeMin + normalRangeBand; // band limit
        }
      } else if (newValue > normalRangeMax) { // else check max
        normalRangeMax = newValue;
        if (normalizationScale == normalMode::slide) {
          normalRangeMin = normalRangeMax - normalRangeBand; // band limit
        }
      }

    // no break;
    case normalMode::custom:
    case normalMode::steer:
      if (normalizationScale == normalMode::steer) {
        if (newValue == normalRangeBand) { // band as threshold
          // do nothing
          newValue = value;
        } else if (newValue < normalRangeBand) {
          newValue = value - (Toolkit::mapf(newValue, normalRangeBand, (normalRangeBand-1.0), POL_NORMALIZE_MIN, POL_NORMALIZE_MAX) * normalRangeDecay); // decay as amplification
        } else if (newValue > normalRangeBand) {
          newValue = value + (Toolkit::mapf(newValue, normalRangeBand, (normalRangeBand+1.0), POL_NORMALIZE_MIN, POL_NORMALIZE_MAX) * normalRangeDecay); // decay as amplification
        }
      } else {
        // Scale the input to the min/max
        newValue = Toolkit::mapf(newValue, normalRangeMin, normalRangeMax, POL_NORMALIZE_MIN, POL_NORMALIZE_MAX);
      }

      // Clipping goes here right?

      // Clip: clip, overflow
      switch (normalizationClip) {
        case normalClip::clip:
        case normalClip::invert:
          // clip output
          newValue = Toolkit::constrainf(newValue, POL_NORMALIZE_MIN, POL_NORMALIZE_MAX);
          // Invert (only okay if output is clipped since it uses 1-x)
          newValue = (normalizationClip == normalClip::invert) ? (1.0 - newValue) : newValue;
          break;
        case normalClip::overflow:
        default:
          break;
      }

    // no break;
    case normalMode::none:
    // no break;
    default:
      break;
  }


  // Absotule must be done at the end so it can handle negative mapping
  newValue = normalAbsolute ? abs(newValue) : newValue;

  // Finally (drumroll), set the internal value
  // TODO - new "steer" mode has effect here
  // will be +/- not just copy
  value = newValue;

  // Set the state

  bool newState = value > 0.5 ? true : false;
  if (newState != state) {
    state = newState;
    //stateChange = (state == false) ? 1 : 2;
    stateChange = state + 1;
  }

}


float Neuron::getValue() {
  return value;
}

float Neuron::getRawValue() {
  return rawValue;
}

void Neuron::setValueIsValid(bool newValid) {
  valueIsValid = newValid;
}
bool Neuron::getValueIsValid() {
  return valueIsValid;
}


bool Neuron::getState() {
  return state;
}

bool Neuron::getDown() {
  if (stateChange == 2) {
    stateChange = 0;
    return true;
  } else {
    return false;
  }
}

bool Neuron::getUp() {
  if (stateChange == 1) {
    stateChange = 0;
    return true;
  } else {
    return false;
  }
}


// ==================================================================
// Normalize
// ---
// Mode: none, automatic, custom, slide, steer
// Clip: clip, overflow, invert
// The four parameters change depending on the mode
//	- automatic: p1 is decay, p2 is frame-skip, p3 is band [p4 not used]
//	- custom: p1/p2 are min/max for range [p3,p4 not used]
//	- slide: p1 is band [p2,3,4 not used]
//	- steer: p1/p2 are min/max range, p3 is threshold, p4 is amplification
// 


//void Neuron::setNormal(normalMode newScale=normalMode::automatic, normalClip newClip=normalClip::overflow, float p1=0.0, float p2=0.0, bool newAbs=false, bool newInv=false) {
void Neuron::setNormal(
  normalMode newScale = normalMode::automatic,
  normalClip newClip = normalClip::clip,
  float p1 = 0.0,
  float p2 = 0.0,
  float p3 = 0.0,
  float p4 = 0.0,
  bool newAbs = false
) {
  // Set the basic things
  normalizationScale = newScale;
  normalizationClip = newClip;
  normalAbsolute = newAbs;
  
  // How tu use p1&p2?
  switch (newScale) {
    case normalMode::automatic:
      normalRangeDecay = p1;
      frameSkipDecay = (byte)p2;
      setNormalRange(0.5, 0.5); // reset both to mid-range
      normalRangeBand = p3;
      break;
    case normalMode::custom:
      setNormalRange(p1, p2);
      break;
    case normalMode::slide:
      normalRangeBand = p1;
      // p2 is not used
      break;
    case normalMode::steer:
      setNormalRange(p1, p2);
      normalRangeBand = p3; // band as threshold
      normalRangeDecay = p4; // decay as amplification
      break;
    default:
      break;
  }
}




void Neuron::doNormalDecay() {
  // Decay verification
  if ( ( (frameSkipDecay == 0) || (frameTimer.getCycles() % frameSkipDecay == 0) ) // have we skipped enough frames?
       && normalizationScale == normalMode::automatic // are we using automatic scale mode?
       && normalRangeDecay != 0) { // is the decay not zero?

    //Serial.println("decay");

    // calculate the center point, how the value relates to the min/max boundry
    float ratio = (rawValue - normalRangeMin) / (normalRangeMax - normalRangeMin);

    // if the new band is larger than the band min
    if ( normalRangeBand != -1 && ((normalRangeMax - normalRangeMin) - normalRangeDecay) > normalRangeBand) {
      // push the levels in toward each other
      normalRangeMin += normalRangeDecay * ratio;
      normalRangeMax -= normalRangeDecay * (1.0 - ratio);
    }

    // This should not occur, but if it does, reset required
    if (normalRangeMin > normalRangeMax) {
      normalRangeMin = getValue();
      normalRangeMax = getValue();
    }

  }
}



void Neuron::setNormalRange(float newMin, float newMax) {
  normalRangeMin = newMin;
  normalRangeMax = newMax;
}

float Neuron::getNormalMin() {
  return normalRangeMin;
}

float Neuron::getNormalMax() {
  return normalRangeMax;
}

// ==================================================================
