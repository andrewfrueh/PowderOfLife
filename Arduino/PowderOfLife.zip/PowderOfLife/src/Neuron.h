/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Neuron
  
  ===========================

  TODO
   
  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2022
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

==================================================================================================== */



/*
  TODO
  - enhance inputNeuron stuff
  - Sensors should have none
  - drivers should have one
  - nodes should have multi?
  - inheritance?
*/

class Neuron {
  private:
    // ===================
    // the current value
    float rawValue;
    float value;
    bool valueIsValid = true;
    bool state;
    byte stateChange; // 0 is null, 1 is down, 2 is up
    // internal states
    bool enabled = true;
    byte currentInvalidMode;
    // frame timer
    Timer frameTimer;
    byte frameSkipDecay; // decay auto normal every x frames
    // ===================
    // automatic / custom normalizing
    float normalRangeMin;
    float normalRangeMax;
    float normalAlt1; // alt var 1
    float normalAlt2; // alt var 2
    // We can use char for storing the enum options as the enums are defined internally
    byte normalizationMode;
    byte normalizationClip;
    bool normalAbsolute;
    // ===================
    // Virtual methods will be overwritten in subclasses (# may need to be "protected" #)
  protected:
    // ===================
    // reference to the input neuron
    //Neuron* inputNeuron;
    // ===================
    /*
      // Input neuron
      void setInput(Neuron &newNeuron); // C++ use Neuron by reference
      Neuron& getInput(); // C++ use Neuron by reference
      bool hasInput();
    */
    virtual void setInput();//Neuron &newNeuron); // C++ use Neuron by reference
    virtual Neuron& getInput(); // C++ use Neuron by reference
    virtual bool hasInput();
    // ===================
    virtual void wake();
    virtual void workFast();
    virtual void work();
    // ===================
    void doNormalDecay();
  public:
    // Constructor
    Neuron();
    // ===================
    // Core functionality
    void start();
    void update();
    void setEnabled(bool newEnabled);
    bool getEnabled();
    void setFrameTime(float newTime);
    float getFrameTime();
    float getFrameDelta();
    // ===================
    // Internal value
    void setValue(float newValue);
    float getValue();
    float getRawValue();
    bool getState(); // current binary state
    void setValueIsValid(bool newValid);
    bool getValueIsValid();
    byte getInvalid();
    void setInvalid(byte newInvalid);
    // ===================
    // These are pseudo-events, but they are easy to use. keep them even if you get actual events working
    bool getDown(); // on down, true only once
    bool getUp(); // on up, true only once
    // ===================
    // Enum lists for options
    enum invalidMode : byte { hold, min, mid, max };
    enum normalMode : byte { none, automatic, custom, slide, steer }; // type of normalization to apply to the input
    enum normalClip : byte { clip, overflow, invert }; // to clip or not to clip the output,
    // ===================
    // Normalize
    void setNormal(
      normalMode newScale = normalMode::automatic,
      normalClip newClip = normalClip::clip,
      float p1 = 0.0,
      float p2 = 0.0,
      float p3 = 0.0,
      float p4 = 0.0,
      bool newAbs = false
    );
    void setNormalClip(normalClip newClip = normalClip::clip);
    // ===================
    // Input range
    void setNormalRange(float newMin, float newMax);
    float getNormalMin();
    float getNormalMid();
    float getNormalMax();
    // ===================
};

// Constructor
Neuron::Neuron() {
  setFrameTime(NEURON_FRAME_TIME);
  setNormal(normalMode::automatic, normalClip::clip, NEURON_NORMAL_DECAY, NEURON_NORMAL_FRAME_SKIP, NEURON_NORMAL_BAND);
  setInvalid(invalidMode::hold);
}

// ==================================================================
// Core functionality

// To be called by the main program
void Neuron::start() {
  // Calls startup on instance
  wake();
}

void Neuron::update() {
  // The main loop
  if ( enabled ) {
    // workFast is outside the frame timer
    workFast();
    // Render a frame?
    if (frameTimer.interval()) {
      // work() is inside the frame timer
      work();
      // Decay auto levels?
      doNormalDecay();
    }
  } else {
    // Neuron is disabled
  }
}

// These virtual methods are to be overridden by subclasses

// To be overridden
void Neuron::wake() {
}

// To be overridden
void Neuron::workFast() {
}

// To be overridden
void Neuron::work() {
}


/*
  // one day...
  // To be overridden
  void Neuron::onDown() {
  }

  // To be overridden
  void Neuron::onUp() {
  }
*/

void Neuron::setEnabled(bool newEnabled) {
  enabled = newEnabled;
}

bool Neuron::getEnabled() {
  return enabled;
}


void Neuron::setFrameTime(float newTime) {
  frameTimer.setRate(newTime);
}

// Arduino can't work the float math for micros
float Neuron::getFrameTime() {
  return frameTimer.getRate();
}

float Neuron::getFrameDelta() {
  return frameTimer.getDelta();
}


// ==================================================================
// Input neuron


// Virtual versions, to be overridden
void Neuron::setInput() {
}
Neuron& Neuron::getInput() {
}
bool Neuron::hasInput() {
}


/*
  // C++ use Neuron by reference
  void Neuron::setInput(Neuron &newNeuron) {
  inputNeuron = &newNeuron;
  }

  // C++ use Neuron by reference
  Neuron& Neuron::getInput() {
  return *inputNeuron;
  }


  bool Neuron::hasInput() {
  return (inputNeuron != NULL) ? true : false;
  }
*/


// ==================================================================
// Value


void Neuron::setValue(float newValue) {

  // Record the newValue to rawValue (even if it is invalid). After this, newValue is used dynamically.
  rawValue = newValue;

  // valid / invalid check... disables write of value
  if (valueIsValid) {
    // Scale: none, automatic, custom
    switch (normalizationMode) { // for C++ use case: static_cast<normalMode>(normalizationMode)
      case normalMode::automatic:
      case normalMode::slide:

        // Modify normalize min/max if needed (bounds)
        if (rawValue < normalRangeMin) { // check min
          normalRangeMin = rawValue;
          if (normalizationMode == normalMode::slide) {
            normalRangeMax = normalRangeMin + normalAlt2; // band limit
          }
        } else if (rawValue > normalRangeMax) { // else check max
          normalRangeMax = rawValue;
          if (normalizationMode == normalMode::slide) {
            normalRangeMin = normalRangeMax - normalAlt2; // band limit
          }
        }

      // no break;
      case normalMode::custom:
      case normalMode::steer:

        // Steer specific, passed if custom
        if (normalizationMode == normalMode::steer) {
          if (newValue == normalAlt2) { // band as threshold
            // do nothing
            newValue = value;
          } else if (newValue < normalAlt2) {
            newValue = value - (Toolkit::mapf(newValue, normalAlt2, (normalAlt2 - 1.0), POL_NORMALIZE_MIN, POL_NORMALIZE_MAX) * normalAlt1); // decay as amplification
          } else if (newValue > normalAlt2) {
            newValue = value + (Toolkit::mapf(newValue, normalAlt2, (normalAlt2 + 1.0), POL_NORMALIZE_MIN, POL_NORMALIZE_MAX) * normalAlt1); // decay as amplification
          }
        } else {
          // Scale the input to the min/max
          newValue = Toolkit::mapf(newValue, normalRangeMin, normalRangeMax, POL_NORMALIZE_MIN, POL_NORMALIZE_MAX);
        }

        // Clip: clip, overflow
        switch (normalizationClip) {
          case normalClip::clip:
          case normalClip::invert:
            // clip output
            newValue = Toolkit::constrainf(newValue, POL_NORMALIZE_MIN, POL_NORMALIZE_MAX);
            // Invert (only okay if output is clipped since it uses 1-x)
            newValue = (normalizationClip == normalClip::invert) ? (1.0 - newValue) : newValue;
            break;
          case normalClip::overflow:
          default:
            break;
        }

      // no break;
      case normalMode::none:
      // no break;
      default:
        break;
    }


    // Absotule must be done at the end so it can handle negative mapping
    newValue = normalAbsolute ? abs(newValue) : newValue;

    // Finally (drumroll), set the internal value
    value = newValue;



    // Set the state
    bool newState = value > 0.5 ? true : false;
    if (newState != state) {
      state = newState;
      //stateChange = (state == false) ? 1 : 2;
      stateChange = state + 1;
    }

  }// valid / invalid wrapper

}


float Neuron::getValue() {
  // Value is valid
  if (valueIsValid) {
    return value;
  } else {
    // Value is NOT valid... decide what to do
    switch (getInvalid()) {
      case invalidMode::hold:
        // use value... it should not have changed due to invalid
        return value;
        break;
      case invalidMode::min:
        // use normal min
        return POL_NORMALIZE_MIN; // getNormalMin();
        break;
      case invalidMode::mid:
        // use normal mid
        return POL_NORMALIZE_MIN + ((POL_NORMALIZE_MAX - POL_NORMALIZE_MIN) / 2); // getNormalMid();
        break;
      case invalidMode::max:
        // use normal max
        return POL_NORMALIZE_MAX; // getNormalMax();
        break;
    }
  }

}


float Neuron::getRawValue() {
  return rawValue;
}

void Neuron::setValueIsValid(bool newValid) {
  valueIsValid = newValid;
}
bool Neuron::getValueIsValid() {
  return valueIsValid;
}


void Neuron::setInvalid(byte newInvalid) {
  currentInvalidMode = newInvalid;
}

byte Neuron::getInvalid() {
  return currentInvalidMode;
}



bool Neuron::getState() {
  return state;
}

bool Neuron::getDown() {
  if (stateChange == 2) {
    stateChange = 0;
    return true;
  } else {
    return false;
  }
}

bool Neuron::getUp() {
  if (stateChange == 1) {
    stateChange = 0;
    return true;
  } else {
    return false;
  }
}


// ==================================================================
// Normalize
// ---
// Mode: none, automatic, custom, slide, steer
// Clip: clip, overflow, invert
// The four parameters change depending on the mode
//	- automatic: p1 is decay, p2 is frame-skip, p3 is band [p4 not used]
//	- custom: p1/p2 are min/max for range [p3,p4 not used]
//	- slide: p1 is band [p2,p3,p4 not used]
//	- steer: p1/p2 are min/max range, p3 is threshold, p4 is amplification
//


//void Neuron::setNormal(normalMode newScale=normalMode::automatic, normalClip newClip=normalClip::overflow, float p1=0.0, float p2=0.0, bool newAbs=false, bool newInv=false) {
void Neuron::setNormal(
  normalMode newScale = normalMode::automatic,
  normalClip newClip = normalClip::clip,
  float p1 = 0.0,
  float p2 = 0.0,
  float p3 = 0.0,
  float p4 = 0.0,
  bool newAbs = false
) {
  // Set the basic things
  normalizationMode = newScale;
  normalizationClip = newClip;
  normalAbsolute = newAbs;

  // How tu use p1&p2?
  switch (newScale) {
    case normalMode::automatic:
      normalAlt1 = p1;
      frameSkipDecay = (byte)p2;
      setNormalRange(0.5, 0.5); // reset both to mid-range
      normalAlt2 = p3;
      break;
    case normalMode::custom:
      setNormalRange(p1, p2);
      break;
    case normalMode::slide:
      normalAlt2 = p1;
      // p2 is not used
      break;
    case normalMode::steer:
      setNormalRange(p1, p2);
      normalAlt2 = p3; // band as threshold
      normalAlt1 = p4; // decay as amplification
      break;
    default:
      break;
  }
}




void Neuron::doNormalDecay() {
  // Decay verification
  if ( ( (frameSkipDecay == 0) || (frameTimer.getCycles() % frameSkipDecay == 0) ) // have we skipped enough frames?
       && normalizationMode == normalMode::automatic // are we using automatic scale mode?
       && normalAlt1 != 0) { // is the decay not zero?

    //Serial.println("decay");

    // calculate the center point, how the value relates to the min/max boundry
    float ratio = (rawValue - normalRangeMin) / (normalRangeMax - normalRangeMin);

    // if the new band is larger than the band min
    if ( normalAlt2 != -1 && ((normalRangeMax - normalRangeMin) - normalAlt1) > normalAlt2) {
      // push the levels in toward each other
      normalRangeMin += normalAlt1 * ratio;
      normalRangeMax -= normalAlt1 * (1.0 - ratio);
    }

    // This should not occur, but if it does, reset required
    if (normalRangeMin > normalRangeMax) {
      normalRangeMin = getValue();
      normalRangeMax = getValue();
    }

  }
}



void Neuron::setNormalRange(float newMin, float newMax) {
  normalRangeMin = newMin;
  normalRangeMax = newMax;
}

float Neuron::getNormalMin() {
  return normalRangeMin;
}

float Neuron::getNormalMid() {
  switch (normalizationMode) {
    case normalMode::steer:
      // Use the steering threshold as mid
      return normalAlt2;
      break;
    default:
      return normalRangeMin + ((normalRangeMax - normalRangeMin) / 2);
      break;
  }
}

float Neuron::getNormalMax() {
  return normalRangeMax;
}

void Neuron::setNormalClip(normalClip newClip = normalClip::clip){
  normalizationClip = newClip;
}

// ==================================================================
