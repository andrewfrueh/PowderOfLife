/* ====================================================================================================

  Powder Of Life
  Serial Sensor
    extends Sensor

---
  
  Reads from the serial port. Used to create a channel for connecting to Neurons outside of this Arduino context.
   
---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the 
  GNU General Public License as published by the Free Software Foundation, either version 3 of the 
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

==================================================================================================== */


// Required for string conversion in C
#include <stdlib.h>
#include <stdio.h>


/*
  Each driver/sensor pair needs to be on the same channel. The driver is the sender, the sensor is the receiver.
  So, you pick a name, and that becomes the name of that channel.
  It is proper broacasting: multiple senders or recievers on the same channel.
*/

class SerialSensor : public Sensor {
  private:
    String inputBuffer;
    bool messageIsActive = false;
    String currentMessage;
    void readSerialData();
    void routeMessage(String newMessage);
    int stringToInt(String text);
    float stringToFloat(String text);
    String channelName;
  protected:
  public:
    SerialSensor();
    //
    void work();
    void setName(String newName);
};


// constructor
SerialSensor::SerialSensor() {

}


void SerialSensor::work() {
  // check for incoming serial data
  readSerialData();
}


void SerialSensor::readSerialData() {
  //
  int lenTemp = Serial.available();

  if (lenTemp > 0) {
    char incomingByte;
    for (int i = 0; i < lenTemp; i++) {
      // read the incoming byte:
      incomingByte = Serial.read();

      switch (incomingByte) {
        case SERIAL_MESSAGE_OPEN: // open tag
          //
          messageIsActive = true;
          inputBuffer = "";
          break;
        case SERIAL_MESSAGE_CLOSE: // close tag
          //
          if (messageIsActive) {
            routeMessage(inputBuffer);
            messageIsActive = false;
          }
          break;
        default: // tag contents?
          if (messageIsActive) {
            inputBuffer += incomingByte;
          }
      }
    }
  }

}


void SerialSensor::routeMessage(String newMessage) {
  String dataName;
  String dataValue;
  int splitIndex;

  splitIndex = newMessage.indexOf(SERIAL_PAIR_SPLIT);
  dataName = newMessage.substring( 0, splitIndex ); // from start up to split
  dataValue = newMessage.substring( splitIndex + 1 ); // from after split to the end

  // now, what do we do?
  // - check that this is our message
  // - if it is, then set our internal value with the new value
  if (dataName == channelName) {
    // name matches, this is my data
    setValue(stringToFloat(dataValue));
    // debug
    //Serial.println(stringToFloat(dataValue));
  }


}


// ====================================
// convert from String to int, so the incoming message can be used in math
// TODO, move this to the Neuron. Maybe make a float version.
// ====================================
// taken from -- http://www.arduino.cc/cgi-bin/yabb2/YaBB.pl?num=1285085509
// probably needs improvement
int SerialSensor::stringToInt(String text) {
  char temp[20];
  text.toCharArray(temp, 19);
  int x = atoi(temp);
  if (x == 0 && text != "0")
  {
    x = -1;
  }
  return x;
}



// by extension from above
float SerialSensor::stringToFloat(String text) {
  char temp[20];
  char *p;
  text.toCharArray(temp, 19);
  //fgets (temp,256,stdin);
  //float x = atof(temp); // text or temp?
  float x = strtod(temp, &p);

  /*
    if (x == 0 && text != "0")
    {
      x = -1;
    }
  */


  return x;
}


void SerialSensor::setName(String newName) {
  channelName = newName;
}
