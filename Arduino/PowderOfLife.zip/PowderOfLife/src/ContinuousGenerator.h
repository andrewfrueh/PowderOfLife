/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Continuous Generator
  
  ===========================

  TODO
   
  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2024
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

==================================================================================================== */




class ContinuousGenerator : public Generator {
  private:
    //
  public:
    ContinuousGenerator();
};


ContinuousGenerator::ContinuousGenerator() {
  //
}

// EOF
