/* ====================================================================================================

  Powder Of Life
  Encoded Motor Node
    extends Node

---
  
  This is a complex node that combines multiple neurons into a neural cluster that makes up an encoded motor.
  
  It uses:
      EncoderSensor
      ButtonSensor
      ButtonSensor
      MotorDriver

---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the 
  GNU General Public License as published by the Free Software Foundation, either version 3 of the 
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

==================================================================================================== */

/*
  TODO:
  x Expose the motor speed variables with a Setter
  - expose the easing too
  - Record the range from wake up and reuse it on collision
    - Since the range between endstops doesn't often change, we can assume that it is correct from WakeUp
  x create a state machine for WakeUp to control the steps for calibration, etc.
  - Add a rate of change mode to the EncoderSensor

*/

#define ENCODEDMOTORNODE_WAKEUP_MOTORSPEED 0.75 // multiplied by the default speed below
#define ENCODEDMOTORNODE_NORMAL_MOTORSPEED 0.5
#define ENCODEDMOTORNODE_LOW_VALUE_GATE 0.02 // weird kludge, but good, BUT no, use below
#define ENCODEDMOTORNODE_MIN_VALUE 0.3
#define ENCODEDMOTORNODE_POSITION_EASING EasyEaseEasingTypes::out
#define ENCODEDMOTORNODE_ENDSTOP_COLLISIONS 10
#define ENCODEDMOTORNODE_ENDSTOP_COLLISION_TIMEOUT 0.2

class EncodedMotorNode : public Node { // should be Node but it's not updating, so I'm using Sensor for now
  private:
    EncoderSensor ES;
    ButtonSensor BS1;
    ButtonSensor BS2;
    MotorDriver MD;
    
    //DEPRICATED
    //EasyEase EE;

    // TODO - use Curvinator to replace EasyEase
    
    //
    EncodedMotorMainStates mainState = EncodedMotorMainStates::sleep;
    EncodedMotorWakeUpStates wakeUpState;
    //
    int endstopCollisionCount = 0;
    Timer endstopCollisionTimeout;
    //
    float motorSpeedDefault = ENCODEDMOTORNODE_NORMAL_MOTORSPEED;
    void ZeroAutoMin();
    void ZeroAutoMax();
    /*
      int encoderPin1;
      int encoderPin2;
      int buttonPin1;
      int buttonPin2;
      int motorPin1;
      int motorPin2;
    */
  protected:
    Neuron* inputNeurons[1];

  public:
    EncodedMotorNode();
    //
    void WakeUp();
    void SetPin( int newEncoderPin1, int newEncoderPin2, int newButtonPin1, int newButtonPin2, int nweMotorPin1, int nweMotorPin2 );
    void Do();
    void UpdateSubcomponents(); // TODO, move this into the parent type as override
    void SetupSubcomponents(); // same
    void SetMotorSpeed(float newSpeed);
};

EncodedMotorNode::EncodedMotorNode() {
  //
  SetupSubcomponents();
  endstopCollisionTimeout.SetRate(ENCODEDMOTORNODE_ENDSTOP_COLLISION_TIMEOUT);
  //
  //WakeUp();
}


void EncodedMotorNode::WakeUp() {
  Serial.println("WakeUp()");

  // initialize wake up process
  mainState = EncodedMotorMainStates::wakeUp;
  wakeUpState = EncodedMotorWakeUpStates::endStop1;
  MD.SetVerified(true);
  endstopCollisionCount = 0;
  endstopCollisionTimeout.Reset();
}


void EncodedMotorNode::Do() {
  //Serial.println("DO (only if Sensor... why?)");
  UpdateSubcomponents();

  // Main state machine
  switch (mainState) {
    case EncodedMotorMainStates::sleep:
      // do nothing
      break;
    case EncodedMotorMainStates::wakeUp:
      // Wake up state machine


      switch (wakeUpState) {
        case EncodedMotorWakeUpStates::endStop1:
          // When endstop is hit, move to the next step in the wake up
          if (BS1.GetState()) {
            Serial.println("endStop1 hit");
            wakeUpState = EncodedMotorWakeUpStates::endStop2;
          }
          // run motor to first endstop until button is detected (this might need to be in the WakeUp method so it only happens once)
          MD.SetValue(-(motorSpeedDefault * ENCODEDMOTORNODE_WAKEUP_MOTORSPEED));
          //MD.Update();
          break;
        case EncodedMotorWakeUpStates::endStop2:
          // When endstop is hit, move to the next step in the wake up (could move up into if() for single-run)
          if (BS2.GetState()) {
            Serial.println("endStop2 hit");
            wakeUpState = EncodedMotorWakeUpStates::done;
          }
          // run motor to second endstop
          MD.SetValue((motorSpeedDefault * ENCODEDMOTORNODE_WAKEUP_MOTORSPEED));
          //MD.Update();
          break;
        case EncodedMotorWakeUpStates::done:
          Serial.println("done");
          // set the input neruon (do we need to break this connection when wake up begins?)
          MD.SetValue(0);
          // wake up is finished, move on to the next main state
          mainState = EncodedMotorMainStates::normal;
          endstopCollisionTimeout.Reset();

          break;
        default:
          // do nothing
          break;
      }
      // TODO
      break;
    case EncodedMotorMainStates::normal:
      /*
      */

      // Check for endstop collision, reset min/max as needed
      // kludge, these are reversed... boo! it could change depending on physical setup
      if (endstopCollisionTimeout.Timeout()) {
        if (BS1.GetState()) {
          //Serial.println("BS1");
          //ES.ZeroAutoMax();
          endstopCollisionCount++;
          endstopCollisionTimeout.Reset();
        }
        if (BS2.GetState()) {
          //Serial.println("BS2");
          //ES.ZeroAutoMin();
          endstopCollisionCount++;
          endstopCollisionTimeout.Reset();
        }
        /*
          if (endstopCollisionCount > ENCODEDMOTORNODE_ENDSTOP_COLLISIONS) {
          //Serial.println("WAKE");
          WakeUp();
          }
        */
      }


      // Do we need to move to sync up the encoder and motor?
      if (GetInputNeuron().GetValue() == ES.GetValue()) {
        // Input neuron and encoder agree. Do nothing.
      } else {
        float x = ES.GetValue() - GetInputNeuron().GetValue();
        //int s = getSign(x);

        // with easing near target
        //x = EasyEase::Ease(absf(x), 0, 1, ENCODEDMOTORNODE_MIN_VALUE, 1, "ExpoOut") * getSign(x); //*motorSpeedDefault; //ENCODEDMOTORNODE_POSITION_EASING
        // gate the low values to get rid of the whine of the motor driver
        x = Toolkit::absf(x) < ENCODEDMOTORNODE_LOW_VALUE_GATE ? 0.0 : x;
        //x = EasyEase::Ease(Toolkit::absf(x), 0, 1, ENCODEDMOTORNODE_MIN_VALUE, 1, ENCODEDMOTORNODE_POSITION_EASING) * Toolkit::getSign(x); //*motorSpeedDefault;

        
        MD.SetValue(x * motorSpeedDefault);

        // no easing, proportional motor speed
        //MD.SetValue(x * motorSpeedDefault);

        // no easing, full speed
        //MD.SetValue(motorSpeedDefault * getSign(x));
      }

      break;
    default:
      // do nothing
      break;
  }
}

void EncodedMotorNode::UpdateSubcomponents() {
  ES.Update();
  BS1.Update();
  BS2.Update();
  MD.Update();

}

void EncodedMotorNode::SetupSubcomponents() {
  // kludge, fit it
  MD.SetVerified(true);
  //MD.SetInvert(true);
  //ES.SetAutoRange(true);
  ES.SetNormalize(NEURONNORMALIZEINPUT_AUTOMATIC);

  ES.SetInvert(false); // depending on the physical setup
}


void EncodedMotorNode::SetPin( int newEncoderPin1, int newEncoderPin2, int newButtonPin1, int newButtonPin2, int nweMotorPin1, int nweMotorPin2 ) {
  //
  ES.SetPin( newEncoderPin1, newEncoderPin2 );
  BS1.SetPin( newButtonPin1 );
  BS2.SetPin( newButtonPin2 );
  MD.SetPin( nweMotorPin1, nweMotorPin2 );
}

void EncodedMotorNode::SetMotorSpeed(float newSpeed) {
  motorSpeedDefault = newSpeed;
}

// like SetAutoMin(), except keeps the current autorange
void EncodedMotorNode::ZeroAutoMin() {
  SetValue(inputRangeMin);
}
void EncodedMotorNode::ZeroAutoMax() {
  SetValue(inputRangeMax);
}
