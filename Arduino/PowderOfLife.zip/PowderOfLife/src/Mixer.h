



class Mixer {

  private:
    Mixer();
  public:
    enum modes : byte { add, subtract, multiply, divide, screen, overlay, difference, min, max, less, greater, modulo, power, average };
    static float Mix(float a, float b, modes mode);
};

// Constructor
Mixer::Mixer() {
}

float Mixer::Mix(float a, float b, Mixer::modes mode) {
  float c;
  switch (mode) {
    case modes::add:
      c = a + b;
      break;
    case modes::subtract:
      c = a - b;
      break;
    case modes::multiply:
      c = a * b;
      break;
    case modes::divide:
      c = b != 0 ? (a / b) : 1;
      break;
    case modes::screen:
      c = 1 - ((1 - a) * (1 - b));
      break;
    case modes::overlay:
      c = b < 0.5 ? 2 * a * b : (1 - (2 * (1 - a) * (1 - b)));
      break;
    case modes::difference:
      c = abs(a - b);
      break;
    case modes::min:
      c = a < b ? a : b;
      break;
    case modes::max:
      c = a > b ? a : b;
      break;
    case modes::less:
      c = a < b ? 1 : 0;
      break;
    case modes::greater:
      c = a > b ? 1 : 0;
      break;
    case modes::modulo:
      c = fmod(a,b); //a % b; // fmod is float-modulo and part of C++
      break;
    case modes::power:
      c = pow(a, b);
      break;
    case modes::average:
      c = (a + b) / 2;
      break;
    default:
      c = 0;
      break;
  }
  //
  return c;
}
