

/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Curve Node

  ===========================

  TODO

  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2024
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

  ==================================================================================================== */


class CurveNode : public Node {
  private:
    byte currentCurveType;
    float currentCurveExponent;
  public:
    CurveNode();
    void work();
    void setCurve(Curvinator::mode newCurve, float newExponent = 2 ); //currentCurveType
};

CurveNode::CurveNode() {
  setNormal(normalMode::custom, normalClip::clip, 0, 1);
}

void CurveNode::work() {
  if (hasInput()) {
    // Simply transfer value like the clone node, but apply Curvinator
    setInternalValue(Curvinator::curve(getInput().getValue(), currentCurveExponent, currentCurveType));
  }
}

void CurveNode::setCurve(Curvinator::mode newCurve, float newExponent = 2 ) {
  currentCurveType = newCurve;
  currentCurveExponent = newExponent;
}


// EOF
