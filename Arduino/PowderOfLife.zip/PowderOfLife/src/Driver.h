/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Driver
  
  ===========================

  TODO
   
  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2024
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

==================================================================================================== */



class Driver : public Neuron{
  protected:
      // ===================
    // reference to the input neuron
    Neuron* inputNeuron;
    // ===================
    // Value
  public:
    Driver();
    // ===================
    // Input neuron
    void setInput(Neuron &newNeuron); // C++ use Neuron by reference
    Neuron& getInput(); // C++ use Neuron by reference
    bool hasInput();
    void updateInput();
    void setValue(float newValue); 
};

// Constructor
Driver::Driver(){
}


// C++ use Neuron by reference
void Driver::setInput(Neuron &newNeuron) {
  inputNeuron = &newNeuron;
}

// C++ use Neuron by reference
Neuron& Driver::getInput() {
  return *inputNeuron;
}


bool Driver::hasInput() {
  return (inputNeuron != NULL) ? true : false;
}

void Driver::updateInput(){
  if (hasInput()) {
    // Grab the value from the input
    setValue(getInput().getValue());
  }
}


void Driver::setValue(float newValue) {
  setInternalValue(newValue);
}


// EOF
