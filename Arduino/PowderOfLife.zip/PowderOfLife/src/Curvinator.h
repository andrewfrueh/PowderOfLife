/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Curvinator
  
  ===========================

  TODO
   
  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2022
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

==================================================================================================== */






class Curvinator {
  private:
    Curvinator();
  public:
    enum mode : byte { none, in, out, inOut, outIn, bell, skew, bathtub }; // These conflict with the method names! Why?
    static float curve(float x, float e, mode newMode, boolean invX, boolean invY );
    static float curveIn(float x, float e);
    static float curveOut(float x, float e);
    static float curveOutIn(float x, float e);
    static float curveInOut(float x, float e);
    static float curveBell(float x, float e);
    static float curveSkew(float x, float e);
    static float curveBathtub(float x, float e);
    // Conversion
    //static types stringToType(String typeString);
};

// Constructor
Curvinator::Curvinator() {
}



// Wrapper method
// x is input, e is exponent, type is type
float Curvinator::curve(float x, float e, mode newMode, boolean invX = false, boolean invY = false  ) {
  
  // x axis inversion
  x = invX ? 1 - x : x;
  
  // switch on type (routing)
  switch (newMode) {
    case mode::none:
      // work nothing
      break;
    case mode::in:
      x = curveIn(x, e);
      break;
    case mode::out:
      x = curveOut(x, e);
      break;
    case mode::inOut:
      x = curveInOut(x, e);
      break;
    case mode::outIn:
      x = curveOutIn(x, e);
      break;
    case mode::bell:
      x = curveBell(x, e);
      break;
    case mode::skew:
      x = curveSkew(x, e);
      break;
    case mode::bathtub:
      x = curveBathtub(x, e);
      break;
    default:
      // work nothing
      break;
  }

  // y axis inversion
  x = invY ? 1 - x : x;

  return x;
}


// ========================================================
// My own Variable Exponent easing. It takes the place of Quad, Cubic, Quint, etc.

float Curvinator::curveIn(float x, float e) {
  return pow(x, e);
}
float Curvinator::curveOut(float x, float e) {
  return 1 - pow(abs(x - 1), e); // pow doesn't like negative numbers, hence 1-pow()
}

// ========================================
// These compound curves are built piecewise from in and out above.
float Curvinator::curveOutIn(float x, float e) {
  return x < 0.5 ?
         curveOut(x * 2, e) / 2 :
         (curveIn((x - 0.5) * 2, e) / 2) + 0.5;
}
float Curvinator::curveInOut(float x, float e) {
  return x < 0.5 ?
         curveIn(x * 2, e) / 2 :
         (curveOut((x - 0.5) * 2, e) / 2) + 0.5;
}

// ===========================================
// bell Vari is as good as Expo Vari above

float Curvinator::curveBell(float x, float e) {
  return (pow(sin(x * PI), e) / 2) * 2;
}

float Curvinator::curveSkew(float x, float e) {
  return ( pow(x, e) - pow(x, e * 2) ) * 4;
}

float Curvinator::curveBathtub(float x, float e) {
  return pow( (abs(x - 0.5) * 2), e );
}

// ==========================================
// Conversion

/*
Curvinator::types Curvinator::stringToType(String typeString){

  curvinatorTypes returnType;

  if (typeString == "none") {
    returnType = curvinatorTypes::none;
  }else if (typeString == "in") {
    returnType = curvinatorTypes::in;
  }else if (typeString == "out") {
    returnType = curvinatorTypes::out;
  }else if (typeString == "inOut") {
    returnType = curvinatorTypes::inOut;
  }else if (typeString == "outIn") {
    returnType = curvinatorTypes::outIn;
  }else if (typeString == "bell") {
    returnType = curvinatorTypes::bell;
  }else if (typeString == "skew") {
    returnType = curvinatorTypes::skew;
  }else if (typeString == "bathtub") {
    returnType = curvinatorTypes::bathtub;
  }else{
    returnType = curvinatorTypes::none;
  }

  return returnType;
  
}
*/
