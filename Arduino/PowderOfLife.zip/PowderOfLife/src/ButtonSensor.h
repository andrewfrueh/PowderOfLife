/* ====================================================================================================

  Powder Of Life
  Button Sensor

  ---

  WHY DOES THIS NOT EXTEND DIGITAL INPUT SENSOR???

  ---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the
  GNU General Public License as published by the Free Software Foundation, either version 3 of the
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

  ==================================================================================================== */

#define BUTTONSENSOR_LERP_SPEED 0.4
#define BUTTONSENSOR_LERP_ACCEL 0.4
#define BUTTONSENSOR_DEBOUNCE_DEPTH 3

class ButtonSensor : public Sensor {
  private:
    bool rawInput;
    byte digitalInputPin;
    bool toggleEnabled;
    bool buttonState;
    // work I really need two variables to work this?
    bool upStateBuffer;
    bool downStateBuffer;
    bool usePullup;
    bool shortToGround = true;
    // This stuff is not used... yet
    //bool debounces[BUTTONSENSOR_DEBOUNCE_DEPTH];
    //bool Debounce(bool newState);
  public:
    ButtonSensor();
    //
    void workFast();
    void work();
    void setPin(int newPin, bool newPullup=true);
    void setToggle(bool newToggle);
};


// constructor
ButtonSensor::ButtonSensor() {
  setNormal(normalMode::custom, normalClip::clip, 0, 1); 
}


void ButtonSensor::workFast() {
  rawInput = digitalRead(digitalInputPin);
  rawInput = shortToGround ? !rawInput : rawInput;
  //rawInput = Debounce(rawInput);
}


void ButtonSensor::work() {
  // rawInput should be 0 or 1 only

  // State change (f the raw state, and button state are different)
  if (buttonState != rawInput) {
    // override the button state with the raw state
    buttonState = shortToGround?rawInput:!rawInput;
    // Toggle?
    if (toggleEnabled) {
      // On down
      if (buttonState) {
        if(getState()){
          setValue(0);
        }else{
          setValue(1);
        }
      }
    } else {
      // button is momentary
      setValue((int)buttonState);
    } 

  } // END state change check

}

/*
// Debounce is not implimented yet... it didn't seem necessary
bool ButtonSensor::Debounce(bool newState){
  byte sum;
  for(byte i=0; i<BUTTONSENSOR_DEBOUNCE_DEPTH; i++){
    sum += debounces[i];
  }
  return sum/BUTTONSENSOR_DEBOUNCE_DEPTH;
}
*/


void ButtonSensor::setPin(int newPin, bool newPullup=true) {
  digitalInputPin = newPin;
  usePullup = newPullup;
  pinMode(digitalInputPin, usePullup?INPUT_PULLUP:INPUT);
}

void ButtonSensor::setToggle(bool newToggle) {
  toggleEnabled = newToggle;
}





// =====================================
