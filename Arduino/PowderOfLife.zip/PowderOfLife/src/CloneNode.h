/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Clone Node
  
  ===========================

  TODO
   
  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2022
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

==================================================================================================== */


class CloneNode : public Node {
  private:
  public:
    CloneNode();
    void work();
    void setValue(float newValue);
};

CloneNode::CloneNode(){
  setNormal(normalMode::none);
}

void CloneNode::work() {

  updateInput();
    
  // simply clone the input
  //setInternalValue(getInput().getValue());
  // also transfer invalid?
  //setInvalid(getInput().getInvalid());
}

void CloneNode::setValue(float newValue) {
  setInternalValue(newValue);
}


// EOF
