/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Clone Node
  
  ===========================

  TODO
   
  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2022
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

==================================================================================================== */


class CloneNode : public Node {
  private:
  public:
    CloneNode();
    void work();
};

CloneNode::CloneNode(){
  setNormal(normalMode::none);
}

void CloneNode::work() {
  // simply clone the input
  setValue(getInput().getValue());
  // also transfer invalid?
  //setInvalid(getInput().getInvalid());
}

// EOF
