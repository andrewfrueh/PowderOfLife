/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Beat Generator
  
  ===========================

  TODO.
   
  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2022
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

==================================================================================================== */


/* TODO
  ADd a "duty cycle" feature. Currently a "tempo" of 60 gives you 1 sec. up then 1 sec down. WTF? So, tempo=60, but only in 2/4 time?
  A tempo of 60 should give you one beat each second. So up... then down again within that one second. 
  Default is 0.5 duty cycle, so with tempo 60, 1/2 sec. up, 1/2 sec. down (double the current rate).
*/
  

class BeatGenerator : public Generator {
  private:
    Timer pulse;
    float tempo;
    float decayTime; // the duty-cycle
    float decayRatio; // the duty-cycle
    byte currentDecayMode;
    //bool onDownTrigger;// kludge supreme... needs to be an event!!!
    void updateDecayTime();
  public:
    BeatGenerator();
    //
    enum decayMode : byte  { ratio, time };
    //
    void work();
    void setTempo(float newTempo);
    float getTempo();
    void setDecay(float newDecay, decayMode newMode=decayMode::ratio);
    float getDecay();
};


BeatGenerator::BeatGenerator() {
  //
  setDecay(0.5, decayMode::ratio);
  setTempo(60);
 
}



void BeatGenerator::work() {

  if(pulse.interval()){
    // Top of the beat
    setValue(1.0);
    //callback();
  }else if(pulse.getElapsed()> decayTime ){
    setValue(0.0);
  }else{
    // do nothing
  }

}


void BeatGenerator::setTempo(float newTempo) {
  tempo = newTempo;
  float s = (60 / tempo); 
  pulse.setRate( s );
  updateDecayTime();
}



float BeatGenerator::getTempo() {
  return tempo;
}

// Decay is the duty cycle
void BeatGenerator::setDecay(float newDecay, decayMode newMode=decayMode::ratio){
  if(newMode == decayMode::ratio){
    decayRatio = newDecay;
    updateDecayTime();
  }else{
    decayTime = newDecay;
  }
  //decay = newDecay;
  currentDecayMode = newMode;
}

float BeatGenerator::getDecay(){
  return decayTime;
}

void BeatGenerator::updateDecayTime(){
  // Decay needs to be adjusted here only if it is "ratio" mode. Else, leave it alone.
  decayTime = (currentDecayMode == decayMode::ratio) ? pulse.getRate() * decayRatio : decayTime;
}




// ===== EOF =====
