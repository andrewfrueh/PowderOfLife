/* ====================================================================================================

  Powder Of Life
  Beat Generator

  ---

  TODO.

  ---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the
  GNU General Public License as published by the Free Software Foundation, either version 3 of the
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

  ==================================================================================================== */


/* TODO
  ADd a "duty cycle" feature. Currently a "tempo" of 60 gives you 1 sec. up then 1 sec down. WTF? So, tempo=60, but only in 2/4 time?
  A tempo of 60 should give you one beat each second. So up... then down again within that one second. 
  Default is 0.5 duty cycle, so with tempo 60, 1/2 sec. up, 1/2 sec. down (double the current rate).
*/
  
#define BEATGENERATOR_DEFAULT_TEMPO 60
#define BEATGENERATOR_DEFAULT_DECAY 0.5

#define BEATGENERATOR_LERPMODE_NONE "none"
#define BEATGENERATOR_LERPMODE_BOTH "both"
#define BEATGENERATOR_LERPMODE_UP "up"
#define BEATGENERATOR_LERPMODE_DOWN "down"

class BeatGenerator : public Generator {
  private:
    Timer pulse;
    float tempo;
    bool lerpBeat = false;
    byte lerpMode;
    bool upDown = false;
    float decay = BEATGENERATOR_DEFAULT_DECAY; // the duty-cycle
    //RailcarLerp beatLerper;
    //bool onDownTrigger;// kludge supreme... needs to be an event!!!
  public:
    BeatGenerator();
    //
    //enum mode : byte  { none, both, up, down };
    //
    void work();
    void setTempo(float newTempo);
    float getTempo();
    void setDecay(float newDecay);
    float getDecay();
    
    //void setLerp(bool newState, mode newMode);
    //bool getLerp();
};


BeatGenerator::BeatGenerator() {
  //
  setTempo(BEATGENERATOR_DEFAULT_TEMPO);
  setDecay(BEATGENERATOR_DEFAULT_DECAY);

  // These are already done by the Generator class
  //SetNormalize(NEURONNORMALIZEINPUT_CUSTOM);
  //SetInputRange(POL_NORMALIZE_MIN, POL_NORMALIZE_MAX);
}



void BeatGenerator::work() {

  if(pulse.interval()){
    // Top of the beat
    setValue(1.0);
    //callback();
  }else if(pulse.getElapsed()>decay){
    setValue(0.0);
  }else{
    // do nothing
  }

}


void BeatGenerator::setTempo(float newTempo) {
  tempo = newTempo;
  float s = (60 / tempo); 
  pulse.setRate( s );
  //beatLerper.SetSpeed( s, s*0.001 );
}

float BeatGenerator::getTempo() {
  return tempo;
}

// Decay is the duty cycle
void BeatGenerator::setDecay(float newDecay){
  decay = newDecay;
}

float BeatGenerator::getDecay(){
  return decay;
}



/*
void BeatGenerator::setLerp(bool newState, mode newMode ) {
  lerpBeat = newState;
  lerpMode = newMode;
}

bool BeatGenerator::getLerp() {
  return lerpBeat;
}
*/

// ===== EOF =====
