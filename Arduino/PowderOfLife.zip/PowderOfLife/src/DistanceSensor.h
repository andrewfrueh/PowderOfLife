/* ====================================================================================================

  Powder Of Life
  Distance Sensor

---

  TODO

---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the 
  GNU General Public License as published by the Free Software Foundation, either version 3 of the 
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

==================================================================================================== */

// *#*#*#*#*#*#
// TODO!
//  - Decide what the value should be depending on validity (defalut, or stay the same?)
//    see recordDistance()
//  - Explain the weird behavoir of the distance sensor in the header (need to check validity)


class DistanceSensor : public Neuron {
  private:
    byte triggerPin;
    byte echoPin;
    //
    unsigned long pingTime = 0;
    unsigned long echoTime = 0;
    int maxEchoDistance = 600;
    //
    int distance = -1;
    //
    bool pulseIsActive = false;
    bool echoIsActive = false;
    //
    unsigned long microsecondsToInches(unsigned long microseconds);
    unsigned long microsecondsToCentimeters(unsigned long microseconds);
    void recordDistance();
  protected:
  public:
    DistanceSensor();
    // Overidden
    void wake();
    void work();
    void workFast();
    void setPin(int newTriggerPin, int newEchoPin);
    //
    void sendPing();
    void checkEcho();
};

DistanceSensor::DistanceSensor() {
  setNormalize(Neuron::normalMode::automatic, Neuron::normalClip::clip, 1, 2, 10);
  setFrameTime(0.1);
}

void DistanceSensor::wake() {
}

void DistanceSensor::workFast() {
  checkEcho();
}

void DistanceSensor::work() {
  sendPing();
}

void DistanceSensor::setPin(int newTriggerPin, int newEchoPin) {
  triggerPin = newTriggerPin;
  echoPin = newEchoPin;
  pinMode(triggerPin, OUTPUT); // digital
  pinMode(echoPin, INPUT); // analog
}

/*
void DistanceSensor::setPin(int newPin1, int newPin2, bool newPullup=false) {
  triggerPin = newPin1;
  echoPin = newPin2;
  pinMode(triggerPin, newPullup?INPUT_PULLUP:INPUT);
  pinMode(echoPin, newPullup?INPUT_PULLUP:INPUT);
}

*/

// ===========
void DistanceSensor::sendPing() {
  digitalWrite(triggerPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(triggerPin, LOW);
  //
  pingTime = micros();
  echoTime = 0;
  pulseIsActive = true;
  echoIsActive = false;

}


void DistanceSensor::checkEcho() {
  if ( pulseIsActive == true ) {
    if ( digitalRead(echoPin) == HIGH && echoIsActive == false) {
      echoIsActive = true;
      echoTime = micros();
    } else if (digitalRead(echoPin) == LOW && echoIsActive == true) {
      echoIsActive = false;
      echoTime = micros() - echoTime;
      pulseIsActive = false;
      //
      recordDistance();
    }
  }
}


void DistanceSensor::recordDistance() {
  distance = microsecondsToCentimeters(echoTime);
  if (distance < maxEchoDistance) {
    setValueIsValid(true);
    setValue(distance); // TODO... add default behavior
  } else {
    setValueIsValid(false);
  }
}


// From the Arduino internal example for "ping"

unsigned long DistanceSensor::microsecondsToInches(unsigned long microseconds) {
  // According to Parallax's datasheet for the PING))), there are 73.746
  // microseconds per inch (i.e. sound travels at 1130 feet per second).
  // This gives the distance travelled by the ping, outbound and return,
  // so we divide by 2 to get the distance of the obstacle.
  // See: http://www.parallax.com/dl/docs/prod/acc/28015-PING-v1.3.pdf
  return microseconds / 74 / 2;
}

unsigned long DistanceSensor::microsecondsToCentimeters(unsigned long microseconds) {
  // The speed of sound is 340 m/s or 29 microseconds per centimeter.
  // The ping travels out and back, so to find the distance of the object we
  // take half of the distance travelled.
  return microseconds / 29 / 2;
}
