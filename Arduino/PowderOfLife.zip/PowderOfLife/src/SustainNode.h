


class SustainNode : public Node {
  private:
    bool reverse;
    float threshold;
    Timer sustainTimer;
  protected:
    float frameTime = 0.001;
  public:
    SustainNode();
    //
    void work();
    void setTime(float newTime);
    void setLevel(float newLevel);
    void setReverse(bool newReverse);
};


// constructor
SustainNode::SustainNode() {
  setTime(1.0);
  setLevel(0.5);
  setReverse(false);
}

void SustainNode::setTime(float newTime) {
  sustainTimer.setRate(newTime);
}

// What the hell is the point of this method?
// SAME as SetValue()
void SustainNode::setLevel(float newLevel) {
  threshold = newLevel;
}

void SustainNode::setReverse(bool newReverse) {
  reverse = newReverse;
}

void SustainNode::work() {

  float input = getInput().getValue();

  //
  if ( (!reverse && (getInput().getValue() > threshold) && (getInput().getValue() > getValue())) ||
       (reverse && (getInput().getValue() < threshold) && (getInput().getValue() < getValue()))
     ) {
    // if input is higher
    setValue( getInput().getValue() );
    //setValue( holdHigh ? 1 : 0 );
    sustainTimer.reset();
  }

  if ( sustainTimer.timeout()) {
    setValue( reverse ? 1 : 0 );
  } else {
    // do nothing
  }

}

// =====================
