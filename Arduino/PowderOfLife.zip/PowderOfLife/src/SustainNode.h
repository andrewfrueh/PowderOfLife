


class SustainNode : public Neuron {
  private:
    bool binaryOutput = false;
    bool holdHigh = true;
    float threshold;
    Timer sustainTimer;
  protected:
    float frameTime = 0.001;
  public:
    SustainNode();
    //
    void work();
    void setTime(float newTime);
    void setLevel(float newLevel);
    void setHold(bool newHold);
};


// constructor
SustainNode::SustainNode() {
  setTime(1.0);
  setLevel(0.5);
  setHold(true);
}

void SustainNode::setTime(float newTime) {
  sustainTimer.setRate(newTime);
}

// What the hell is the point of this method?
// SAME as SetValue()
void SustainNode::setLevel(float newLevel) {
  threshold = newLevel;
}

void SustainNode::setHold(bool newHold) {
  holdHigh = newHold;
}

void SustainNode::work() {

  //
  if ( holdHigh && getInputNeuron().getValue() > threshold ||
       !holdHigh && getInputNeuron().getValue() < threshold ) {
    // if input is higher
    setValue( getInputNeuron().getValue() );
    sustainTimer.reset();
  }

  if ( sustainTimer.timeout()) {
    setValue( holdHigh ? 0 : 1 );
  }

}

// =====================
