/* ====================================================================================================

  Powder Of Life
  Lerp Node

---

  TODO

---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the 
  GNU General Public License as published by the Free Software Foundation, either version 3 of the 
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

==================================================================================================== */

class LerpNode : public Neuron{
  private:
    //
  public:
    // Constructor
    LerpNode();
    // Lerp
    RailcarLerp lerp;
    //
    void work();
    void wake();
    void setLerp(float newSpeed, float newAcceleration);
};

LerpNode::LerpNode(){
  
  setNormalize(normalizeScale::none);
  lerp.setSpeed(1.0);
  lerp.setAcceleration(0.1);
}

void LerpNode::wake(){
}


void LerpNode::work(){
  //Serial.println(getFrameDelta());
  lerp.setTarget(getInputNeuron().getValue());
  lerp.update(getFrameDelta());
  setValue(lerp.getValue());
}

void LerpNode::setLerp(float newSpeed, float newAcceleration){
  lerp.setSpeed(newSpeed);
  lerp.setAcceleration(newAcceleration);
}
