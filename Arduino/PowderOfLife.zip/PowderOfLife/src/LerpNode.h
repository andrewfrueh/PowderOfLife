/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Lerp Node
  
  ===========================

  TODO
   
  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2022
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

==================================================================================================== */



class LerpNode : public Node{
  private:
    //
  public:
    // Constructor
    LerpNode();
    // Lerp
    RailcarLerp lerp;
    //
    void work();
    void wake();
    void setLerp(float newSpeed, float newAcceleration);
};

LerpNode::LerpNode(){
  
  setNormal(normalMode::none);
  lerp.setSpeed(1.0);
  lerp.setAcceleration(0.1);
}

void LerpNode::wake(){
}


void LerpNode::work(){
  //Serial.println(getFrameDelta());
  lerp.setTarget(getInput().getValue());
  lerp.update(getFrameDelta());
  setValue(lerp.getValue());
}

void LerpNode::setLerp(float newSpeed, float newAcceleration){
  lerp.setSpeed(newSpeed);
  lerp.setAcceleration(newAcceleration);
}
