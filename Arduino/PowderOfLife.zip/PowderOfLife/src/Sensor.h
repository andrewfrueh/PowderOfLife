


class Sensor : public Neuron{
  protected:
  public:
    Sensor();
};

// Constructor
Sensor::Sensor(){
}
