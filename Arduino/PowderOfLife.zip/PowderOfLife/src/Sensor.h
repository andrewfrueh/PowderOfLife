/* ====================================================================================================

  Powder Of Life
  Arduino Library
  ---
  Sensor

  ===========================

  TODO

  ===========================

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2024
  Powder Of Life is under the GNU General Public License. See "LICENSE.txt" file included with this library.

  ==================================================================================================== */


// TODO
// - add control for digital / analog input pin


class Sensor : public Neuron {
  private:
    bool valueIsValid = true;
    byte currentInvalidMode;
    byte currentPinType;
    bool currentPinPullup;
  protected:
  public:
    Sensor();
    //
    enum invalidMode : byte { hold, min, mid, max };
    enum pinType : byte { digital, analog };
    //
    //void setValueIsValid(bool newValid);
    //bool getValueIsValid();
    byte getInvalid();
    void setInvalid(byte newInvalid);
    float getInvalidValue();
    void setPinType(pinType newType);
    byte getPinType();
    void setPinPullup(bool newType);
    bool getPinPullup();
    void setPinInputMode(int pin);

    // this is the new stuff... we go dancing in
    bool digitalReadMod(int pin);
};

// Constructor
Sensor::Sensor() {
  setInvalid(invalidMode::hold);
  //setPinType(pinType::digital);
}


/*
  void Sensor::setValueIsValid(bool newValid) {
  valueIsValid = newValid;
  }
  bool Sensor::getValueIsValid() {
  return valueIsValid;
  }
*/


void Sensor::setInvalid(byte newInvalid) {
  currentInvalidMode = newInvalid;
}

byte Sensor::getInvalid() {
  return currentInvalidMode;
}


float Sensor::getInvalidValue() {
  switch (getInvalid()) {
    case invalidMode::hold:
      // use value... it should not have changed due to invalid
      return getValue();
      break;
    case invalidMode::min:
      // use normal min
      return POL_NORMALIZE_MIN; // getNormalMin();
      break;
    case invalidMode::mid:
      // use normal mid
      return POL_NORMALIZE_MIN + ((POL_NORMALIZE_MAX - POL_NORMALIZE_MIN) / 2); // getNormalMid();
      break;
    case invalidMode::max:
      // use normal max
      return POL_NORMALIZE_MAX; // getNormalMax();
      break;
  }
}


void Sensor::setPinType(pinType newType) {
  currentPinType = newType;
}

byte Sensor::getPinType() {
  return currentPinType;
}

void Sensor::setPinPullup(bool newPullup) {
  currentPinPullup = newPullup;
}

bool Sensor::getPinPullup() {
  return currentPinPullup;
}

void Sensor::setPinInputMode(int pin) {
  switch (currentPinType) {
    case digital:
      pinMode(pin, getPinPullup() ? INPUT_PULLUP : INPUT);
      break;
    case analog:
      // do nothing
      break;
  }

}

// Really just a wrapper that acts like digitalRead() but can route to either analog or digital
bool Sensor::digitalReadMod(int pin) {
  switch (currentPinType) {
    case digital:
      return digitalRead(pin);
      break;
    case analog:
      return analogRead(pin) < ((ANALOG_INPUT_MAX - ANALOG_INPUT_MIN) / 2) ? false : true;
      break;
  }
}










// EOF
