/* ====================================================================================================

  Powder Of Life
  Motor Driver

  ---

  Controls a basic DC motor driver board (two pins: digital direction, PWM speed).

  ---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the
  GNU General Public License as published by the Free Software Foundation, either version 3 of the
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

  ==================================================================================================== */


// TODO
// control DC motor with a basic driver
// how to determine direction?
//  - two inputs fighting
//  - each is weighted, affects outcome

class MotorDriver : public Neuron {
  private:
    int outputDirPin; // digital
    int outputSpeedPin; // analog
    //
    //bool useCenterOffset = false;
    //float centerOffsetPoint;
    //int outputSpeed;
  protected:
    //Neuron* inputNeurons[1];
  public:
    MotorDriver();
    //
    void work();
    void setPin(int newDirPin, int newSpeedPin);
};


// constructor
MotorDriver::MotorDriver() {
  // Using normalize with 0.5 to 1.0 so it reverses.
  setNormalize(normalMode::custom, normalClip::overflow, 0.5, 1.0);
}

void MotorDriver::work() {

  //
  setValue(getInputNeuron().getValue());
  
  // create output temp
  float outputSpeed = Toolkit::constrainf(getValue(),-POL_NORMALIZE_MAX,POL_NORMALIZE_MAX);

  // Handle -/+ value to change direction
  digitalWrite(outputDirPin, outputSpeed<0.0?LOW:HIGH);

  // map output for speed
  outputSpeed = Toolkit::mapf(Toolkit::absf(outputSpeed), POL_NORMALIZE_MIN, POL_NORMALIZE_MAX, ANALOG_OUTPUT_MIN, ANALOG_OUTPUT_MAX);
  //outputSpeed = Toolkit::constrainf(outputSpeed, ANALOG_OUTPUT_MIN, ANALOG_OUTPUT_MAX);
  // write output for speed
  analogWrite(outputSpeedPin, outputSpeed);

}


void MotorDriver::setPin(int newDirPin, int newSpeedPin) {
  outputDirPin = newDirPin;
  outputSpeedPin = newSpeedPin;
  pinMode(outputDirPin, OUTPUT); // digital
  pinMode(outputSpeedPin, OUTPUT); // analog
}
