/* ====================================================================================================

  Powder Of Life
  Engine

---

  TODO

---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the 
  GNU General Public License as published by the Free Software Foundation, either version 3 of the 
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

==================================================================================================== */


class Engine {
  private:
    //
    Neuron* inputNeurons[POL_ENGINE_NUM_OF_NEURONS];
    //
    byte nextNewNeuron = 0;
    int currentSerialRate;
    bool engineActive = false;
    bool serialActive = false;
  public:
    // constructor
    Engine();
    //
    void start();
    void update();
    //
    enum serialRate : byte { debug, standard, midi }; // Kludge, I wanted "default" but it's a keyword or something
    // stolen from the old Neuron class (hence "input neuron")
    void setNeuron(Neuron &newNeuron, int index);
    void addNeuron(Neuron &newNeuron);
    Neuron& getNeuron(int index);
    bool hasNeuron(int index);
    byte countNeurons();
    void setSerial(serialRate newRate);
};

// constructor
Engine::Engine() {
  // Note: cannot start the serial in constructor
}



void Engine::start() {
  // Serial was not setup, so do it
  if(!serialActive){
    setSerial(serialRate::debug);
  }
  for (byte i = 0; i < countNeurons(); i++) {
    // update the current component
    inputNeurons[i]->start();
  }
  //
  engineActive = true;
}


void Engine::update() {
  // Engine was not started, so do it
  if(!engineActive){
    start();
  }
  // Here we will update all registered components
  for (byte i = 0; i < countNeurons(); i++) {
    // update the current component
    inputNeurons[i]->update();
  }
}
// You can also work this...
//Neuron n;
//n = *inputNeurons[i];
//n.update();



void Engine::setNeuron(Neuron &newNeuron, int index = 0) {
  //
  inputNeurons[index] = &newNeuron;
}

void Engine::addNeuron(Neuron &newNeuron) {
  // check to see if the "last neuron" is null, else increment the index
  //byte index = (inputNeurons[nextNewNeuron] ==  NULL) ? nextNewNeuron : nextNewNeuron + 1;
  if (&newNeuron != NULL) {
    inputNeurons[nextNewNeuron] = &newNeuron;
    nextNewNeuron++;
  }
}

Neuron& Engine::getNeuron(int index = 0) {
  return *inputNeurons[index];
}

bool Engine::hasNeuron(int index = 0) {

  if (inputNeurons[index] == NULL) {
    return false;
  } else {
    return true;
  }

}

byte Engine::countNeurons() {
  return nextNewNeuron;
}

void Engine::setSerial(serialRate newRate) {
  //
  Serial.end();
  //
  switch (newRate) {
    case serialRate::debug:
      currentSerialRate = SERIAL_BAUD_RATE_DEBUG;
      break;
    case serialRate::standard:
      currentSerialRate = SERIAL_BAUD_RATE_DEFAULT;
      break;
    case serialRate::midi:
      currentSerialRate = SERIAL_BAUD_RATE_MIDI;
      break;
  }
  //
  Serial.begin(currentSerialRate);
  //
  serialActive = true;
}
