/* ====================================================================================================

  Powder Of Life
  Midi Driver

---

  TODO

---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the 
  GNU General Public License as published by the Free Software Foundation, either version 3 of the 
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

==================================================================================================== */

class MidiDriver : public Neuron {
  private:
    float noteBase;
    //int noteOffset;
    //int midiClockModulo = 24;
    //int noteSubdiv = 4;
    //float noteTimerRate = 0.5;
    //Timer noteTimer;
    //Timer clockTimer;
  public:
    MidiDriver();
    void work();
    void wake();
    void setBase(float newBase);
    //void SetOffset(int newOffset);
    //
    void playNote(byte note, byte velocity = 100, byte channel = 1, bool playStop = true);
    void stopNote(byte note, byte channel = 1);
    void sendClock();
    void allNotesOff();
};

MidiDriver::MidiDriver() {
}


void MidiDriver::work() {
  // TODO, nice to have, not need to have... internal timing
  /*
    if (clockTimer.interval() && midiOutput) {
    sendClock();
    }
    if (noteTimer.interval()) {
    playNote();
    }
  */
}

void MidiDriver::wake() {
  /*
    noteTimer.setRate(noteTimerRate / noteSubdiv);
    clockTimer.setRate(noteTimerRate / midiClockModulo);
  */
  setBase(60);
}

void MidiDriver::setBase(float newBase) {
  noteBase = newBase;
}

/*
  void MidiDriver::SetOffset(int newOffset) {

  }
*/

// =================

// 0x7B: All notes off?
// 0x80: Note off (128)
// 0x90: Note on (144)
// 0xA0: Poly pressure (160)
// 0xB0: control change (176)
// 0xE0: pitch bend
// ----
// 0xF8: timing clock (24 per quarter note)
void MidiDriver::playNote(byte note, byte velocity = 100, byte channel = 1, bool playStop = true)
{
  //MIDI channels 1-16 are really 0-15
  byte noteOnStatus = (playStop ? 0x90 : 0x80) + (channel - 1);

  //Transmit a Note-On message
  Serial.write(noteOnStatus);
  Serial.write(note);
  Serial.write(velocity);
}

void MidiDriver::stopNote(byte note, byte channel = 1) {
  byte noteOnStatus = 0x80 + (channel - 1);
  //Transmit a Note-Off message
  Serial.write(noteOnStatus);
  Serial.write(note);
  Serial.write(0);

}


void MidiDriver::sendClock() {
  byte clockByte = 0xF8;
  Serial.write(clockByte);
}

// TODO - This shit don't work!
void MidiDriver::allNotesOff() {
  Serial.write(0x7B);
  /*
    // https://forum.arduino.cc/t/midi-reset/169120/8
    Serial.write(0xF0);
    Serial.write(0x7F);
    Serial.write(0x7F); //device id 7F = 127 all channels
    Serial.write(0x02);
    Serial.write(0x7F); // command format 7F = all devices
    Serial.write(0x0A); // action 0x0A= reset
    Serial.write(0xF7);
  */
  // Serial.write(0xFF);

}
