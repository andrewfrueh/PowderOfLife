/* ====================================================================================================

  Powder Of Life
  Neuron

  ---

  TODO

  ---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the
  GNU General Public License as published by the Free Software Foundation, either version 3 of the
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

  ==================================================================================================== */


/*
  ===== TODO, needs to be recalculated =====
  Current footprint:
  Neuron reference ?x1: ? byte
  float 4x5: 20 bytes
  bool 1x5: 5 bytes
  byte 1x3: 3 bytes
  Timer 14x1: 14 bytes
  ------
  = 50 bytes
*/

class Neuron {
  private:
    // ===================
    // reference to the input neuron
    Neuron* inputNeuron;
    // ===================
    // the current value
    float rawValue;
    float value;
    bool valueIsValid = true;
    bool state;
    byte stateChange; // 0 is null, 1 is down, 2 is up
    // internal states
    bool enabled = true;
    // frame timer
    Timer frameTimer;
    byte frameSkipDecay; // decay auto normal every x frames
    // ===================
    // automatic / custom normalizing
    float normalRangeMin;
    float normalRangeMax;
    float normalRangeDecay; // alt var 1
    float normalRangeBand; // alt var 2
    // We can use char for storing the enum options as the enums are defined internally
    byte normalizationScale;
    byte normalizationClip;
    // ===================
    // Virtual methods will be overwritten in subclasses (# may need to be "protected" #)
    // ===================
    // Normalize
    void doNormalDecay();

  protected:
    // ===================
    virtual void wake();
    virtual void workFast();
    virtual void work();
    // ===================
    // Events (permission will be shifted to public when overridden)
    // How can these work? The receiving neuron imliments? IDK! Barf. Whatever, just use the kludey ones below
    /*
      virtual void onDown();
      virtual void onUp();
    */
  public:
    // Constructor
    Neuron();
    // ===================
    // Core functionality
    void start();
    void update();
    void setEnabled(bool newEnabled);
    bool getEnabled();
    void setFrameTime(float newTime);
    float getFrameTime();
    float getFrameDelta();
    // ===================
    // Input neuron
    void setInputNeuron(Neuron &newNeuron); // C++ use Neuron by reference
    Neuron& getInputNeuron(); // C++ use Neuron by reference
    bool hasInputNeuron();
    // ===================
    // Value
    void setValue(float newValue);
    float getValue();
    float getRawValue();
    bool getState(); // current binary state
    void setValueIsValid(bool newValid);
    bool getValueIsValid();
    void setInvert(bool newInvert);
    // ===================
    // Events
    // getDown/getUp are actually anti-events, but they are easy to use. keep them even if you get actual events working
    bool getDown(); // on down, true only once
    bool getUp(); // on up, true only once
    // ===================
    // enum lists for options
    enum normalizeScale : byte { none, automatic, custom, slide, steer }; // type of normalization to apply to the input
    enum normalizeClip : byte { clip, overflow, invert }; // to clip or not to clip the output,
    // Normalize
    //void setNormalize(normalizeScale newScale=normalizeScale::automatic, normalizeClip newClip=normalizeClip::overflow, float p1=0.0, float p2=0.0, bool newAbs=false, bool newInv=false);
    void setNormalize(
      normalizeScale newScale = normalizeScale::automatic,
      normalizeClip newClip = normalizeClip::clip,
      float p1 = 0.0,
      float p2 = 0.0,
      float p3 = 0.0,
      float p4 = 0.0
    );
    void setNormalScale(normalizeScale newScale);
    Neuron::normalizeScale getNormalScale();
    void setNormalClip(normalizeClip newClip);
    void setNormalAbsolute(bool newAbs);
    void setNormalInvert(bool newInv);
    // ===================
    // Input range
    void setNormalDecay(float newDecay);
    void setNormalBand(float newBand);
    void setNormalFrameSkip(byte newSkip);
    void setNormalRange(float newMin, float newMax);
    float getNormalDecay();
    float getNormalMin();
    float getNormalMax();
    // ===================
};

// Constructor
Neuron::Neuron() {
  setFrameTime(NEURON_FRAME_TIME);
  setNormalFrameSkip(NEURON_NORMAL_FRAME_SKIP);
  setNormalize(normalizeScale::automatic, normalizeClip::clip, NEURON_NORMAL_DECAY, NEURON_NORMAL_FRAME_SKIP, NEURON_NORMAL_BAND);
  //setNormalBand(NEURON_NORMAL_BAND);
}

// ==================================================================
// Core functionality

// To be called by the main program
void Neuron::start() {
  // Calls startup on instance
  wake();
}

void Neuron::update() {
  // The main loop
  if ( enabled ) {
    // workFast is outside the frame timer
    workFast();
    // Render a frame?
    if (frameTimer.interval()) {
      // work() is inside the frame timer
      work();
      // Decay auto levels?
      doNormalDecay();
    }
  } else {
    // Neuron is disabled
  }
}

// These virtual methods are to be overridden by subclasses

// To be overridden
void Neuron::wake() {
}

// To be overridden
void Neuron::workFast() {
}

// To be overridden
void Neuron::work() {
}


/*
  // one day...
  // To be overridden
  void Neuron::onDown() {
  }

  // To be overridden
  void Neuron::onUp() {
  }
*/

void Neuron::setEnabled(bool newEnabled) {
  enabled = newEnabled;
}

bool Neuron::getEnabled() {
  return enabled;
}


void Neuron::setFrameTime(float newTime) {
  frameTimer.setRate(newTime);
}

// Arduino can't work the float math for micros
float Neuron::getFrameTime() {
  return frameTimer.getRate();
}

float Neuron::getFrameDelta() {
  return frameTimer.getDelta();
}


// ==================================================================
// Input neuron

// C++ use Neuron by reference
void Neuron::setInputNeuron(Neuron &newNeuron) {
  inputNeuron = &newNeuron;
}

// C++ use Neuron by reference
Neuron& Neuron::getInputNeuron() {
  return *inputNeuron;
}


bool Neuron::hasInputNeuron() {
  return (inputNeuron != NULL) ? true : false;
}


// ==================================================================
// Value

// TODO - add "slide", NOPE! use "band" instead

void Neuron::setValue(float newValue) {
  rawValue = newValue;

  // Scale: none, automatic, custom
  switch (normalizationScale) { // for C++ use case: static_cast<normalizeScale>(normalizationScale)
    case normalizeScale::automatic:
    case normalizeScale::slide:
      // Learning / memory

      if (newValue < normalRangeMin) { // check min
        normalRangeMin = newValue;
        if (normalizationScale == normalizeScale::slide) {
          normalRangeMax = normalRangeMin + normalRangeBand; // band limit
        }
      } else if (newValue > normalRangeMax) { // else check max
        normalRangeMax = newValue;
        if (normalizationScale == normalizeScale::slide) {
          normalRangeMin = normalRangeMax - normalRangeBand; // band limit
        }
      }

    // no break;
    case normalizeScale::custom:
    case normalizeScale::steer:
      if (normalizationScale == normalizeScale::steer) {
        // *TODO* fix for negative values
        if (newValue == normalRangeBand) { // band as threshold
          // do nothing
          newValue = value;
        } else if (newValue < normalRangeBand) {
          newValue = value - (Toolkit::mapf(newValue, normalRangeBand, normalRangeMin, POL_NORMALIZE_MIN, POL_NORMALIZE_MAX) * normalRangeDecay); // decay as amplification
        } else if (newValue > normalRangeBand) {
          newValue = value + (Toolkit::mapf(newValue, normalRangeBand, normalRangeMax, POL_NORMALIZE_MIN, POL_NORMALIZE_MAX) * normalRangeDecay); // decay as amplification
        }
      } else {
        // Scale the input to the min/max
        newValue = Toolkit::mapf(newValue, normalRangeMin, normalRangeMax, POL_NORMALIZE_MIN, POL_NORMALIZE_MAX);
      }

      // Clipping goes here right?

      // Clip: clip, overflow
      switch (normalizationClip) {
        case normalizeClip::clip:
        case normalizeClip::invert:
          // clip output
          newValue = Toolkit::constrainf(newValue, POL_NORMALIZE_MIN, POL_NORMALIZE_MAX);
          // Invert (only okay if output is clipped since it uses 1-x)
          newValue = (normalizationClip == normalizeClip::invert) ? (1.0 - newValue) : newValue;
          break;
        case normalizeClip::overflow:
        default:
          break;
      }

    // no break;
    case normalizeScale::none:
    // no break;
    default:
      break;
  }


  // Absotule must be done at the end so it can handle negative mapping
  // REMOVED
  //newValue = normalAbsolute ? abs(newValue) : newValue;

  // Finally (drumroll), set the internal value
  // TODO - new "steer" mode has effect here
  // will be +/- not just copy
  value = newValue;

  // Set the state

  bool newState = value > 0.5 ? true : false;
  if (newState != state) {
    state = newState;
    //stateChange = (state == false) ? 1 : 2;
    stateChange = state + 1;
  }

}


float Neuron::getValue() {
  return value;
}

float Neuron::getRawValue() {
  return rawValue;
}

void Neuron::setValueIsValid(bool newValid) {
  valueIsValid = newValid;
}
bool Neuron::getValueIsValid() {
  return valueIsValid;
}


bool Neuron::getState() {
  return state;
}

bool Neuron::getDown() {
  if (stateChange == 2) {
    stateChange = 0;
    return true;
  } else {
    return false;
  }
}

bool Neuron::getUp() {
  if (stateChange == 1) {
    stateChange = 0;
    return true;
  } else {
    return false;
  }
}


// ==================================================================
// Normalize


//void Neuron::setNormalize(normalizeScale newScale=normalizeScale::automatic, normalizeClip newClip=normalizeClip::overflow, float p1=0.0, float p2=0.0, bool newAbs=false, bool newInv=false) {
void Neuron::setNormalize(
  normalizeScale newScale = normalizeScale::automatic,
  normalizeClip newClip = normalizeClip::clip,
  float p1 = 0.0,
  float p2 = 0.0,
  float p3 = 0.0,
  float p4 = 0.0
) {
  // Set the basic things
  setNormalScale(newScale);
  setNormalClip(newClip);
  // How tu use p1&p2?
  switch (newScale) {
    case normalizeScale::automatic:
      setNormalDecay(p1);
      setNormalFrameSkip((byte)p2);
      setNormalRange(0.5, 0.5); // reset both to mid-range
      setNormalBand(p3);
      break;
    case normalizeScale::custom:
      setNormalRange(p1, p2);
      break;
    case normalizeScale::slide:
      setNormalBand(p1);
      // p2 is not used
      break;
    case normalizeScale::steer:
      setNormalRange(p1, p2);
      setNormalBand(p3); // band as threshold
      setNormalDecay(p4); // decay as amplification
      break;
    default:
      break;
  }
}



void Neuron::setNormalScale(normalizeScale newScale) {
  normalizationScale = newScale;
}

Neuron::normalizeScale Neuron::getNormalScale() {
  return normalizationScale;
}

void Neuron::setNormalClip(normalizeClip newClip) {
  normalizationClip = newClip;
}


void Neuron::doNormalDecay() {
  // Decay verification
  if ( ( (frameSkipDecay == 0) || (frameTimer.getCycles() % frameSkipDecay == 0) ) // have we skipped enough frames?
       && normalizationScale == normalizeScale::automatic // are we using automatic scale mode?
       && normalRangeDecay != 0) { // is the decay not zero?

    //Serial.println("decay");

    // calculate the center point, how the value relates to the min/max boundry
    float ratio = (rawValue - normalRangeMin) / (normalRangeMax - normalRangeMin);

    // if the new band is larger than the band min
    if ( normalRangeBand != -1 && ((normalRangeMax - normalRangeMin) - normalRangeDecay) > normalRangeBand) {
      // push the levels in toward each other
      normalRangeMin += normalRangeDecay * ratio;
      normalRangeMax -= normalRangeDecay * (1.0 - ratio);
    }

    // This should not occur, but if it does, reset required
    if (normalRangeMin > normalRangeMax) {
      normalRangeMin = getValue();
      normalRangeMax = getValue();
    }

  }
}

void Neuron::setNormalDecay(float newDecay) {
  normalRangeDecay = newDecay;
}

float Neuron::getNormalDecay() {
  return normalRangeDecay;
}

void Neuron::setNormalBand(float newBand) {
  normalRangeBand = newBand;
}



void Neuron::setNormalFrameSkip(byte newSkip) {
  frameSkipDecay = newSkip;
}


void Neuron::setNormalRange(float newMin, float newMax) {
  normalRangeMin = newMin;
  normalRangeMax = newMax;
}

float Neuron::getNormalMin() {
  return normalRangeMin;
}

float Neuron::getNormalMax() {
  return normalRangeMax;
}

// ==================================================================
