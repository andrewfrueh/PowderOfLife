/* ====================================================================================================

  Powder Of Life
  Encoder Sensor

---
  
  A specific kind of digital input sensor (perhaps it could extend that type?).
  Used with a twin infrared reflectance sensor and a binary encoder pattern (strip or wheel).
  Uses simple quadrature encoding to determine direction of travel and displacement.
   
---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the 
  GNU General Public License as published by the Free Software Foundation, either version 3 of the 
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

==================================================================================================== */


//#define ENCODERSENSOR_DEFAULT_MODE EncoderSensorMode::range
//#define ENCODERSENSOR_RATEOFCHANGE 0.2

class EncoderSensor : public Neuron {
  private:
    // Properties
    int digitalInputPin1;
    int digitalInputPin2;
    bool usePullup;
    bool inputState1;
    bool inputState2;
    int currentQuadratureState;
    int lastQuadratureState;
    long currentStepCount;
    // this is for rate of change... perhaps implemented at the Neuron level (value change)?
    long lastStepCount;
    Timer rateOfChangeTimer;

    byte encoderMode;
    // Methods
    char CheckPattern(bool x, bool y);
    void QuadratureToStep();
    bool reverseDirection = false;
  protected:
    void wake();
    void work();
    void workFast();
    //float frameTime = 0.001;
  public:
    EncoderSensor();
    //
    enum modes : byte { range, rate};
    enum quadratureStates : byte { a, b, c, d };
    bool quadraturePatterns[4][2] = {
      {0,0},
      {1,0},
      {1,1},
      {0,1},
    };
    //
    void setPin(int newPin1, int newPin2, bool newPullup=false);
    void setMode(modes newMode);
    void setReverse(bool newState);
    void setSteps(int newSteps); // number of steps per output unit
};


// constructor
EncoderSensor::EncoderSensor() {
  // Set the default mode
  setMode(modes::range);
  // Set the rate of change (should this be in work() instead so it can be dynamic?)
  rateOfChangeTimer.setRate(0.2);
  //
  setNormalize(normalizeScale::automatic);
}

void EncoderSensor::wake(){
}


void EncoderSensor::workFast() {
  
  // Read the digital inputs
  inputState1 = digitalRead(digitalInputPin1);
  inputState2 = digitalRead(digitalInputPin2);
  
  // Convert the current input state to a quatrature state
  QuadratureToStep();

  switch (encoderMode) {
    case modes::range:
      // "range" mode
      break;
    case modes::rate:
      // "rate" mode
      break;
    default:
      break;
  }

}


void EncoderSensor::work() {
        //Serial.println(modes::range);

  // Switch on the mode
  switch (encoderMode) {
    case modes::range:
      // "range" mode
      //Serial.println(currentStepCount);
      setValue(currentStepCount);
      break;
    case modes::rate:
      // "rate" mode
      // TODO

      if (rateOfChangeTimer.interval()) {
        setValue(currentStepCount - lastStepCount);
        lastStepCount = currentStepCount;
      }

      //currentStepCount = 0;
      break;
    default:
      break;
  }
}

void EncoderSensor::QuadratureToStep() {

  // check the pattern to figure out what state we are in
  currentQuadratureState = CheckPattern(inputState1, inputState2);

  // Use the state to decide where we are in the pattern
  if ( currentQuadratureState == -1 ) {
    // ERROR, pattern was not matched! work nothing.
  } else if ( lastQuadratureState != currentQuadratureState ) {
    // Check last state against current state to determine movement. (wish it were a switch statement)

    if (currentQuadratureState == 0 && lastQuadratureState == 3) {
      // roll over, going up
      currentStepCount += reverseDirection?-1:1;
    } else if (currentQuadratureState == 3 && lastQuadratureState == 0) {
      // roll over, going down
      currentStepCount -= reverseDirection?-1:1;
    } else {
      // default is to check that we have only moved 1 (+/-)
      int d = (currentQuadratureState - lastQuadratureState);
      currentStepCount += abs(d) == 1 ? (reverseDirection?-d:d) : 0; // if distance is only 1 then use it, else use 0
    }

    // finally, update the prevoius state
    lastQuadratureState = currentQuadratureState;

  }

}

char EncoderSensor::CheckPattern(bool x, bool y) {

  for ( int i = 0; i < 4; i++) {
    if ( x == quadraturePatterns[i][0] && y == quadraturePatterns[i][1] ) {
      return i;
    }
  }

  // This means there was no pattern matched. This should not happen. Check for this.
  return -1;

}


void EncoderSensor::setPin(int newPin1, int newPin2, bool newPullup=false) {
  digitalInputPin1 = newPin1;
  digitalInputPin2 = newPin2;
  usePullup = newPullup;
  pinMode(digitalInputPin1, usePullup?INPUT_PULLUP:INPUT);
  pinMode(digitalInputPin2, usePullup?INPUT_PULLUP:INPUT);
}

void EncoderSensor::setMode(modes newMode) {
  encoderMode = newMode;
}

void EncoderSensor::setReverse(bool newState){
  reverseDirection = newState;
}

void EncoderSensor::setSteps(int newSteps){
  setNormalize(normalizeScale::custom, normalizeClip::overflow, 0, newSteps);
}



// end
