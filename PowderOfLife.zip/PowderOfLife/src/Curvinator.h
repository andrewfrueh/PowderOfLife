/* ====================================================================================================

  Powder Of Life
  Curvinator
    utility class

---

  TODO
    Completely new version. Uses my own ExpoVari easing in place of Cubic, Quad, Quart, etc.

---

  Powder Of Life, Copyright (C) Andrew Frueh, 2019-2021

  Powder Of Life is free software: you can redistribute it and/or modify it under the terms of the 
  GNU General Public License as published by the Free Software Foundation, either version 3 of the 
  License, or (at your option) any later version.

  Powder Of Life is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with Powder Of Life.
  If not, see <https://www.gnu.org/licenses/>.

==================================================================================================== */



enum class curvinatorTypes {
  none, in, out, inOut, outIn, bell, skew, bathtub
};

class Curvinator {
  private:
    Curvinator();
  public:
    static float curve(float x, float e, curvinatorTypes type, boolean invX, boolean invY );
    static float in(float x, float e);
    static float out(float x, float e);
    static float outIn(float x, float e);
    static float inOut(float x, float e);
    static float bell(float x, float e);
    static float skew(float x, float e);
    static float bathtub(float x, float e);
    // Conversion
    static curvinatorTypes stringToType(String typeString);
};

// Constructor
Curvinator::Curvinator() {
}

// Wrapper method
// x is input, e is exponent, type is type
float Curvinator::curve(float x, float e, curvinatorTypes type, boolean invX = false, boolean invY = false  ) {
  
  // x axis inversion
  x = invX ? 1 - x : x;
  
  // switch on type (routing)
  switch (type) {
    case curvinatorTypes::none:
      // work nothing
      break;
    case curvinatorTypes::in:
      x = in(x, e);
      break;
    case curvinatorTypes::out:
      x = out(x, e);
      break;
    case curvinatorTypes::inOut:
      x = inOut(x, e);
      break;
    case curvinatorTypes::outIn:
      x = outIn(x, e);
      break;
    case curvinatorTypes::bell:
      x = bell(x, e);
      break;
    case curvinatorTypes::skew:
      x = skew(x, e);
      break;
    case curvinatorTypes::bathtub:
      x = bathtub(x, e);
      break;
    default:
      // work nothing
      break;
  }

  // y axis inversion
  x = invY ? 1 - x : x;

  return x;
}


// ========================================================
// My own Variable Exponent easing. It takes the place of Quad, Cubic, Quint, etc.

float Curvinator::in(float x, float e) {
  return pow(x, e);
}
float Curvinator::out(float x, float e) {
  return 1 - pow(abs(x - 1), e); // pow doesn't like negative numbers, hence 1-pow()
}

// ========================================
// These compound curves are built piecewise from in and out above.
float Curvinator::outIn(float x, float e) {
  return x < 0.5 ?
         out(x * 2, e) / 2 :
         (in((x - 0.5) * 2, e) / 2) + 0.5;
}
float Curvinator::inOut(float x, float e) {
  return x < 0.5 ?
         in(x * 2, e) / 2 :
         (out((x - 0.5) * 2, e) / 2) + 0.5;
}

// ===========================================
// bell Vari is as good as Expo Vari above

float Curvinator::bell(float x, float e) {
  return (pow(sin(x * PI), e) / 2) * 2;
}

float Curvinator::skew(float x, float e) {
  return ( pow(x, e) - pow(x, e * 2) ) * 4;
}

float Curvinator::bathtub(float x, float e) {
  return pow( (abs(x - 0.5) * 2), e );
}

// ==========================================
// Conversion

curvinatorTypes Curvinator::stringToType(String typeString){

  curvinatorTypes returnType;

  if (typeString == "none") {
    returnType = curvinatorTypes::none;
  }else if (typeString == "in") {
    returnType = curvinatorTypes::in;
  }else if (typeString == "out") {
    returnType = curvinatorTypes::out;
  }else if (typeString == "inOut") {
    returnType = curvinatorTypes::inOut;
  }else if (typeString == "outIn") {
    returnType = curvinatorTypes::outIn;
  }else if (typeString == "bell") {
    returnType = curvinatorTypes::bell;
  }else if (typeString == "skew") {
    returnType = curvinatorTypes::skew;
  }else if (typeString == "bathtub") {
    returnType = curvinatorTypes::bathtub;
  }else{
    returnType = curvinatorTypes::none;
  }

  return returnType;
  
}
